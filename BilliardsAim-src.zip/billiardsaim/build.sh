#!/bin/bash
# build.sh — 在 macOS + Xcode 上编译 BilliardsAim.dylib (arm64 + arm64e FAT)
# 用法: ./build.sh [min_ios_version]   默认 14.0
set -euo pipefail

MIN_IOS="${1:-14.0}"
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src"
OUT="$ROOT/out"
OBJ="$ROOT/.obj"
DYLIB_NAME="BilliardsAim"
INSTALL_NAME="@executable_path/Frameworks/${DYLIB_NAME}.dylib"

mkdir -p "$OUT" "$OBJ"

if ! command -v xcrun >/dev/null 2>&1; then
  echo "错误: 未找到 xcrun, 请在 macOS + Xcode 环境运行本脚本" >&2
  exit 1
fi

SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
echo "SDK: $SDK"
echo "min iOS: $MIN_IOS"

CFLAGS="-isysroot $SDK -miphoneos-version-min=$MIN_IOS -O2 -fPIC -fobjc-arc \
-DNDEBUG -I$SRC"
CXXFLAGS="$CFLAGS -std=gnu++17 -stdlib=libc++"
LDFLAGS="-isysroot $SDK -miphoneos-version-min=$MIN_IOS \
-framework Foundation -framework UIKit -framework QuartzCore \
-framework CoreGraphics -framework CoreFoundation -lobjc"

# 源文件分类
MM_FILES=$(ls "$SRC"/*.mm 2>/dev/null || true)
M_FILES=$(ls "$SRC"/*.m   2>/dev/null || true)
CPP_FILES=$(ls "$SRC"/*.cpp 2>/dev/null || true)

ARCHS="arm64 arm64e"
SLICES=()

for ARCH in $ARCHS; do
  echo "=== 编译 $ARCH ==="
  OBJDIR="$OBJ/$ARCH"
  mkdir -p "$OBJDIR"
  OBJS=()

  for f in $MM_FILES; do
    o="$OBJDIR/$(basename "$f").o"
    xcrun --sdk iphoneos clang++ -arch "$ARCH" $CXXFLAGS -fobjc-arc -c "$f" -o "$o"
    OBJS+=("$o")
  done
  for f in $M_FILES; do
    o="$OBJDIR/$(basename "$f").o"
    xcrun --sdk iphoneos clang -arch "$ARCH" $CFLAGS -c "$f" -o "$o"
    OBJS+=("$o")
  done
  for f in $CPP_FILES; do
    o="$OBJDIR/$(basename "$f").o"
    xcrun --sdk iphoneos clang++ -arch "$ARCH" $CXXFLAGS -c "$f" -o "$o"
    OBJS+=("$o")
  done

  SLICE="$OUT/${DYLIB_NAME}.${ARCH}.dylib"
  xcrun --sdk iphoneos clang++ -arch "$ARCH" $LDFLAGS \
    -dynamiclib -install_name "$INSTALL_NAME" \
    -o "$SLICE" "${OBJS[@]}"
  echo "  -> $SLICE"
  SLICES+=("$SLICE")
done

echo "=== 合并 FAT ==="
xcrun lipo -create "${SLICES[@]}" -output "$OUT/${DYLIB_NAME}.dylib"
xcrun lipo -info "$OUT/${DYLIB_NAME}.dylib"

# ad-hoc 签名（未越狱设备必需；越狱设备 ldid -S 也行）
if command -v ldid >/dev/null 2>&1; then
  ldid -S"$ROOT/config/ent.plist" "$OUT/${DYLIB_NAME}.dylib" 2>/dev/null || ldid -S "$OUT/${DYLIB_NAME}.dylib"
  echo "已用 ldid ad-hoc 签名"
elif command -v codesign >/dev/null 2>&1; then
  codesign -f -s - "$OUT/${DYLIB_NAME}.dylib"
  echo "已用 codesign ad-hoc 签名"
else
  echo "未找到签名工具, 注入前请手动签名"
fi

echo
echo "产物: $OUT/${DYLIB_NAME}.dylib"
ls -l "$OUT/${DYLIB_NAME}.dylib"
