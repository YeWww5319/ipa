/* 最小 string 声明 */
#ifndef BA_STUB_STRING_H
#define BA_STUB_STRING_H
#ifdef __cplusplus
extern "C" {
#endif
void *memset(void *, int, unsigned long);
void *memcpy(void *, const void *, unsigned long);
void *memmove(void *, const void *, unsigned long);
int   memcmp(const void *, const void *, unsigned long);
unsigned long strlen(const char *);
int   strcmp(const char *, const char *);
int   strncmp(const char *, const char *, unsigned long);
char *strstr(const char *, const char *);
char *strcpy(char *, const char *);
#ifdef __cplusplus
}
#endif
#endif
