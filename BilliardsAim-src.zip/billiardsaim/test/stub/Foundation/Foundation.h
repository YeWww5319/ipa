#ifndef STUB_FOUNDATION_H
#define STUB_FOUNDATION_H
#ifndef __OBJC__
typedef unsigned char BOOL;
#ifndef YES
#define YES ((BOOL)1)
#endif
#ifndef NO
#define NO ((BOOL)0)
#endif
#endif
#endif
