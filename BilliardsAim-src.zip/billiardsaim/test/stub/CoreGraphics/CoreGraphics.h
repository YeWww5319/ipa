#ifndef STUB_COREGRAPHICS_H
#define STUB_COREGRAPHICS_H
typedef struct CGPoint { double x; double y; } CGPoint;
typedef struct CGSize  { double width; double height; } CGSize;
static const CGPoint CGPointZero = {0.0, 0.0};
static const CGSize  CGSizeZero  = {0.0, 0.0};
#endif
