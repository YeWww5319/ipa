/* 最小 math 声明, 供交叉编译 iOS 目标时替代系统 math.h */
#ifndef BA_STUB_MATH_H
#define BA_STUB_MATH_H
#ifdef __cplusplus
extern "C" {
#endif
double sqrt(double);
double cos(double);
double sin(double);
double tan(double);
double acos(double);
double asin(double);
double atan2(double, double);
double fabs(double);
double pow(double, double);
double fmod(double, double);
double hypot(double, double);
double fmax(double, double);
double fmin(double, double);
int isnan(double);
int isinf(double);
#ifdef __cplusplus
}
#endif
#define M_PI   3.14159265358979323846
#define M_PI_2 1.57079632679489661923
#define INFINITY  (__builtin_inff())
#define HUGE_VAL  (__builtin_huge_val())
#endif
