#include "BACommon.h"
int c_compat_check(void) {
    BATable t = baDefaultTable();
    BAVec2 a = BAV(1,2), b = BAV(3,4);
    BAResult r; memset(&r, 0, sizeof(r));
    (void)baAdd(a,b); (void)baSub(a,b); (void)baNorm(a);
    (void)baPocketAt(t,0); (void)baPocketCount(t);
    (void)baSolveShot(t,a,b,b,0.85);
    (void)r;
    return 0;
}
