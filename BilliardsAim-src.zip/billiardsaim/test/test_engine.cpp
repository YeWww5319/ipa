#include "BACommon.h"
#include <stdio.h>

static int fails = 0;
#define CHECK(cond, msg, ...) do { \
    if (!(cond)) { printf("  [FAIL] " msg "\n", ##__VA_ARGS__); fails++; } \
    else { printf("  [ok]   " msg "\n", ##__VA_ARGS__); } } while(0)

int main(void) {
    BATable t = baDefaultTable();
    printf("=== 台面默认值 ===\n");
    printf("  L=%.1f W=%.1f R=%.2f decel=%.1f rest=%.2f\n",
           t.length, t.width, t.ballRadius, t.rollDecel, t.cushionRest);
    CHECK(t.length > 200 && t.width > 100, "台面尺寸合理");
    CHECK(baPocketCount(t) == 6, "6 袋");

    printf("\n=== 袋口坐标 ===\n");
    for (int i = 0; i < 6; ++i) {
        BAVec2 p = baPocketAt(t, i);
        printf("  袋%d (%.1f, %.1f)\n", i, p.x, p.y);
        CHECK(p.x >= -0.01 && p.x <= t.length + 0.01, "袋%d x 在台内", i);
        CHECK(p.y >= -0.01 && p.y <= t.width + 0.01, "袋%d y 在台内", i);
    }

    printf("\n=== 场景1: 正对直球 (切角应为 0) ===\n");
    {
        BAVec2 cue    = BAV(50, 63.5);
        BAVec2 target = BAV(150, 63.5);
        BAVec2 pocket = baPocketAt(t, 1);     // (127, 0)? 用右中袋
        pocket = BAV(t.length, t.width * 0.5);
        BAResult r = baSolveShot(t, cue, target, pocket, 0.9);
        printf("  cut=%.3f° ghost=(%.2f,%.2f) feasible=%d\n",
               r.result.cutAngleDeg, r.result.ghost.x, r.result.ghost.y,
               r.result.feasible);
        CHECK(r.valid, "求解有效");
        CHECK(fabs(r.result.cutAngleDeg) < 0.5, "切角≈0 (实际 %.3f)", r.result.cutAngleDeg);
        CHECK(fabs(r.result.ghost.y - target.y) < 0.01, "虚拟球 y 与目标球同高");
        CHECK(r.result.ghost.x < target.x, "虚拟球在目标球后方");
        double expGhostX = target.x - 2 * t.ballRadius;
        CHECK(fabs(r.result.ghost.x - expGhostX) < 0.01,
              "虚拟球 x = 目标球 - 2R (期望 %.2f, 实际 %.2f)", expGhostX, r.result.ghost.x);
    }

    printf("\n=== 场景2: 45度切球 ===\n");
    {
        BAVec2 cue    = BAV(100, 63.5);
        BAVec2 target = BAV(150, 63.5);
        BAVec2 pocket = BAV(150, 0);          // 正上方袋 => 目标球走 +y
        BAResult r = baSolveShot(t, cue, target, pocket, 0.9);
        printf("  cut=%.3f° need=%.1f v0可行=%d\n",
               r.result.cutAngleDeg, r.result.objectNeedSpeed, r.result.feasible);
        CHECK(r.valid, "求解有效");
        CHECK(r.result.cutAngleDeg > 80 && r.result.cutAngleDeg < 100,
              "接近 90° 极限切角 (实际 %.1f)", r.result.cutAngleDeg);
        CHECK(r.result.objPathCount == 2, "目标球路径 2 点");
    }

    printf("\n=== 场景3: 库边坐标准确 ===\n");
    {
        CHECK(fabs(baCushionCoord(t, 0) - 0.0) < 1e-9, "库0 = y=0");
        CHECK(fabs(baCushionCoord(t, 1) - t.width) < 1e-9, "库1 = y=W");
        CHECK(fabs(baCushionCoord(t, 2) - 0.0) < 1e-9, "库2 = x=0");
        CHECK(fabs(baCushionCoord(t, 3) - t.length) < 1e-9, "库3 = x=L");
    }

    printf("\n=== 场景4: 镜像袋口 ===\n");
    {
        BAVec2 pk = BAV(40, 20);
        BAVec2 m0 = baMirrorPocket(t, pk, 0);   // 关于 y=0
        BAVec2 m1 = baMirrorPocket(t, pk, 1);   // 关于 y=W
        printf("  原(%.1f,%.1f) m0=(%.1f,%.1f) m1=(%.1f,%.1f)\n",
               pk.x, pk.y, m0.x, m0.y, m1.x, m1.y);
        CHECK(fabs(m0.y + pk.y) < 1e-9, "关于 y=0 镜像");
        CHECK(fabs(m1.y - (2*t.width - pk.y)) < 1e-9, "关于 y=W 镜像");
        CHECK(fabs(m0.x - pk.x) < 1e-9, "镜像不改 x");
    }

    printf("\n=== 场景5: 滚动距离 (物理一致性) ===\n");
    {
        double v = 300.0;
        double d = baRollDistance(t, v);
        // 解析解: v^2/(2*decel)
        double expect = v*v/(2*t.rollDecel);
        printf("  v=%.0f -> d=%.2f cm (期望 %.2f)\n", v, d, expect);
        CHECK(fabs(d - expect) < 1e-6, "滚动距离公式正确");
        CHECK(baRollDistance(t, 0) < 1e-9, "零速零距");
    }

    printf("\n=== 场景6: 轨迹追踪不越界 ===\n");
    {
        BAVec2 from = BAV(20, 20);
        BAVec2 dir  = BAV(1, 0.6);
        BAVec2 pts[12];
        int n = baTrace(t, from, dir, 600, pts, 12);
        printf("  路径点 %d 个:", n);
        for (int i = 0; i < n; ++i) printf(" (%.1f,%.1f)", pts[i].x, pts[i].y);
        printf("\n");
        CHECK(n >= 2, "至少 2 点");
        CHECK(n <= 12, "不超过容量");
        int inside = 1;
        for (int i = 0; i < n; ++i) {
            if (pts[i].x < -1 || pts[i].x > t.length + 1 ||
                pts[i].y < -1 || pts[i].y > t.width + 1) inside = 0;
        }
        CHECK(inside, "所有点都在台面范围内(含容差)");
    }

    printf("\n=== 场景7: 多球择优 ===\n");
    {
        BAVec2 cue = BAV(50, 63.5);
        BAVec2 balls[4] = { BAV(120,63.5), BAV(60,30), BAV(200,100), BAV(40,110) };
        int idx[4] = {1,2,3,4};
        BAResult best;
        int ok = baBestShot(t, cue, balls, 4, idx, 6, 0.9, &best);
        printf("  选中 球%d 袋%d cut=%.1f° score=%.1f\n",
               best.ballIndex, best.pocketIndex, best.result.cutAngleDeg, best.score);
        CHECK(ok, "找到解");
        CHECK(best.ballIndex >= 1 && best.ballIndex <= 4, "球索引合法");
        CHECK(best.pocketIndex >= 0 && best.pocketIndex < 6, "袋索引合法");
        CHECK(best.result.cutAngleDeg >= 0 && best.result.cutAngleDeg <= 180, "切角合法");
    }

    printf("\n=== 场景8: 翻袋 ===\n");
    {
        BAVec2 cue = BAV(100, 63.5);
        BAVec2 target = BAV(200, 40);
        BAVec2 pocket = baPocketAt(t, 3);   // (0, W)
        BAResult r;
        BOOL ok = baBestBank(t, cue, target, pocket, 1, 0.95, &r);
        printf("  翻袋可行=%d bounces=%d cushion=%d cut=%.1f°\n",
               ok, r.result.bounces, r.result.cushion[0], r.result.cutAngleDeg);
        if (ok) {
            CHECK(r.result.bounces >= 1, "至少 1 次翻库");
            CHECK(r.result.objPathCount == 3, "翻袋路径 3 点");
        } else {
            printf("  [skip] 该几何下无解, 属正常\n");
        }
    }

    printf("\n=== 场景9: 弧线曲率 ===\n");
    {
        double k0 = baCurvatureFromSpin(0.0, 300);
        double k1 = baCurvatureFromSpin(1.0, 300);
        double k2 = baCurvatureFromSpin(1.0, 150);
        printf("  k(0)=%.6f k(1,v300)=%.6f k(1,v150)=%.6f\n", k0, k1, k2);
        CHECK(fabs(k0) < 1e-12, "无旋无曲率");
        CHECK(fabs(k1) > 1e-9, "有旋有曲率");
        CHECK(fabs(k2) > fabs(k1), "低速曲率更大");
    }

    printf("\n=== 场景10: 力度阶梯单调 ===\n");
    {
        BAPowerRow rows[8];
        int n = baPowerLadder(t, BAV(50,63.5), BAV(120,63.5), BAV(200,63.5), rows, 8);
        CHECK(n == 8, "生成 8 档");
        int mono = 1;
        for (int i = 1; i < n; ++i) if (rows[i].speed <= rows[i-1].speed) mono = 0;
        CHECK(mono, "速度单调递增");
        printf("  最小=%.0f 最大=%.0f\n", rows[0].speed, rows[n-1].speed);
    }

    printf("\n=========================\n");
    if (fails == 0) printf("全部通过\n");
    else            printf("失败 %d 项\n", fails);
    return fails ? 1 : 0;
}
