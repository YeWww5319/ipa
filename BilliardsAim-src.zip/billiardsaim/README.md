# BilliardsAim2 — 台球瞄准辅助 dylib（可注入 IPA 版）

从原始 `BilliardsAim.dylib`（arm64/arm64e FAT，iOS 越狱注入型）逆向还原并重写的可编译工程。
**功能对齐原版**：aim line / ghost ball / 目标球路径 / 母球路径 / 切角 / 力度 / 翻袋 / 扎杆 / 四点标定 / HUD / 反检测。

与原版相比的新增能力（原版没有）：
- **偏移自动测绘** `autoProbe` —— 换游戏不用手工摸偏移
- **模块名自动探测** —— 不填 `moduleName` 也能找到主模块
- **IPA 一键注入** —— 纯 Python 改 Mach-O，不依赖 `insert_dylib`
- **引擎单测** —— 10 组几何/物理断言，改参数不怕算错

---

## 1. 目录

```
billiardsaim/
├── src/
│   ├── BACommon.h        公共类型 + 引擎 extern "C" 接口（C/C++ 双兼容）
│   ├── BAEngine.cpp      物理引擎（ghost ball / 切角 / 翻袋 / 弧线 / 力度）
│   ├── BAConfig.h/.m     配置单例，plist 读写，22 项参数
│   ├── BAWorld.h/.m      模块定位 + __DATA 扫描 + 偏移自动测绘
│   ├── BAOverlay.h/.m    主控窗口 / 图层 / 四点标定(DLT) / 每帧绘制 / HUD
│   ├── BAAntiDetect.m    越狱痕迹隐藏（fishhook C 层 + ObjC swizzle）
│   └── BilliardsAim.mm   注入入口（constructor + 1.2s 延迟挂载）
├── bin/
│   ├── machoinject.py    Mach-O 注入器（FAT/thin，纯 Python）
│   ├── pack_ipa.sh       解包 → 注入 → 重签 → 回包
│   ├── ipainfo.sh        IPA 结构探查（bundle/executable/加密状态/反调试关键词）
│   └── resign.sh         单独重签
├── config/
│   ├── com.zaka.billiardsaim.plist   默认配置模板
│   └── ent.plist                     entitlements 模板
├── test/
│   ├── test_engine.cpp   引擎功能测试（10 组）
│   └── stub/             Linux 下语法校验用的 Foundation/CoreGraphics 桩
├── build.sh              编译 dylib（arm64 + arm64e → FAT）
└── Makefile              Theos 备选（出 .deb）
```

---

## 2. 编译（在 macOS + Xcode 上）

```bash
chmod +x build.sh bin/*.sh
./build.sh                 # 默认 min iOS 14.0
./build.sh 15.0            # 指定最低版本
```

产物：`out/BilliardsAim.dylib`（arm64 + arm64e FAT，`install_name` 为
`@executable_path/Frameworks/BilliardsAim.dylib`）。

不依赖 Theos；有 Theos 时也可 `make package` 出 deb。

**Linux 下能做的验证**（无需 SDK）：

```bash
# 语法校验
g++ -std=gnu++17 -fsyntax-only -Itest/stub -Isrc src/BAEngine.cpp
gcc -std=gnu11   -fsyntax-only -Itest/stub -Isrc test/c_compat.c

# 引擎功能测试
g++ -std=gnu++17 -O1 -Itest/stub -Isrc src/BAEngine.cpp test/test_engine.cpp \
    -o test/test_engine -lm && ./test/test_engine
```

---

## 3. 注入 IPA

```bash
./bin/ipainfo.sh 台球世界.ipa              # 先看结构
./bin/pack_ipa.sh 台球世界.ipa out.ipa     # 注入 + 重签 + 回包
```

`pack_ipa.sh` 做的事：

1. 解包，读 `CFBundleExecutable`
2. `dylib` 复制到 `Payload/Xxx.app/Frameworks/BilliardsAim.dylib`
3. `machoinject.py inject` 往主二进制追加
   `LC_LOAD_WEAK_DYLIB @executable_path/Frameworks/BilliardsAim.dylib`
   —— 用 **WEAK** 而非普通 LOAD，dylib 缺失时游戏不会崩，便于排查
4. 剥离所有旧的 `LC_CODE_SIGNATURE`，删 `_CodeSignature/`
5. `ldid -S` 或 `codesign -f -s -` 重签全链
6. 重新 zip

手动分步：

```bash
python3 bin/machoinject.py info   Target.app/Target
python3 bin/machoinject.py check  Target.app/Target @executable_path/Frameworks/BilliardsAim.dylib
python3 bin/machoinject.py inject Target.app/Target @executable_path/Frameworks/BilliardsAim.dylib --weak --inplace
./bin/resign.sh   Target.app [TEAM_ID] [BUNDLE_ID]
```

### 前置条件

- **IPA 必须已脱壳**。`ipainfo.sh` 会打印 `cryptid`：非 0 表示 App Store 加壳，需先
  `frida-ios-dump` 或越狱设备 `dumpdecrypted` 脱壳，否则注入后启动黑屏。
- 目标二进制要有足够 header padding。实测常见游戏有 8–16 KB，`check` 会直接告诉你余量。
- 安装方式：越狱设备直接装；非越狱需自签（Sideloadly/AltStore）并用 `ent.plist` 授权。

---

## 4. 首次运行 —— 这一步决定成败

dylib 挂在 `@executable_path/Frameworks/`，启动即加载，1.2 秒后出 HUD（右侧 4 个方块：`标定` `显示` `翻袋` `测绘`）。

### 4.1 确定目标参数（两种办法）

**办法 A：点 `测绘`（推荐）**

`autoProbe` 会遍历：

| 维度 | 取值 |
|---|---|
| `ballStride` | 16,20,24,28,32,36,40,44,48,56,64,72,80,96,112,128 |
| `ballXOffset` | 0,4,8,12,16,20,24,28,32,40,48,56,64 |
| `ballValueType` | 0=float / 1=double |

采样 `__DATA` 前 12 MB，对每组统计“像球”的单元，按 **命中数 + 互不重叠 + 空间分散度** 打分，最优结果自动写回 plist。日志里会打 `[BA] autoProbe 最优: {...}`。

**办法 B：手填 plist**

```bash
# 设备上
/var/mobile/Library/Preferences/com.zaka.billiardsaim.plist
```

| 键 | 含义 | 起步值 |
|---|---|---|
| `moduleName` | 游戏主模块名，留空则自动取最大非系统镜像 | `""` |
| `ballStride` | 每个球结构体步长（字节） | `24` |
| `ballXOffset` | 坐标 X 在结构内的偏移 | `0` |
| `ballYOffset` | 坐标 Y 在结构内的偏移 | `8` |
| `ballValueType` | `0`=float32 `1`=float64 | `1` |
| `ballCount` | 台面球数 | `16` |
| `coordMode` | `0`=台面cm `1`=屏幕pt `2`=归一化 | `0` |

Unity 系游戏常见 `stride=24, x=0, y=8, type=1`；Cocos/自研常见 `stride=16, x=0, y=4, type=0`。
`ipainfo.sh` 打印的 `CFBundleExecutable` 一般就是 `moduleName` 的候选；Unity 游戏则是 `UnityFramework`。

### 4.2 标定

点 `标定`，**严格按 左上 → 右上 → 右下 → 左下** 顺序点台面四角（不是屏幕四角）。

顺序错会导致单应矩阵镜像翻转，瞄准线跑到台外。四点写入 plist 后永久生效。

内部用 DLT 解 8 元线性方程组得 3×3 投影矩阵：

```
u = (aX + bY + c) / (gX + hY + 1)
v = (dX + eY + f) / (gX + hY + 1)
```

台面透视、倾斜、广角都能正确投影。

---

## 5. 物理参数调优

| 参数 | 含义 | 标准值 | 调法 |
|---|---|---|---|
| `tableLength/Width` | 台面 cm | 254×127（9尺） | 按实际台型 |
| `ballRadius` | 球半径 cm | 2.85 | 斯诺克 2.625，中式八球 2.85 |
| `rollDecel` | 台呢减速 cm/s² | 25 | 慢台 18–22，快台 30–40 |
| `cushionRest` | 库边弹性 | 0.78 | 硬库 0.85，软库 0.65 |
| `maxSpeed` | 满力出杆速度 | 900 | 影响力度百分比换算 |
| `pocketRadius` | 袋口容差 | 9.0 | 大袋 12，窄袋 7 |
| `aimPower` | 当前力度 0–1 | 0.85 | 太小会判“需加力” |

`showBank` 打开后会把翻袋解一起参与择优；`bankBounces` 控制翻库次数上限。
`showMasse` 打开后用 `spinV`/`spinS` 算扎杆弧线（`spinV` 正=高杆，负=低杆）。

---

## 6. 算法说明（与原版对照）

原版 C++ 符号 → 本工程实现：

| 原版符号 | 本工程 | 说明 |
|---|---|---|
| `baDefaultTable` | `baDefaultTable` | 台面默认值 |
| `baRollDistance` | `baRollDistance` | `d = v²/(2·decel)` |
| `baPockets` | `baPocketAt` | 4/6 袋坐标 |
| `baTrace` | `baTrace` | 直线 + 库边反射，逐段求交 |
| `baSolveShot` | `baSolveShot` | **ghost ball**：`g = T − 2R·d̂`，`cut = acos(ĉ·d̂)` |
| `baMirrorPocket` | `baMirrorPocket` | 翻袋镜像法 |
| `baSolveBank`/`baBestBank` | 同名 | 四库遍历 + 共线校验 + 切角上限 82° |
| `baCurvatureFromSpin` | 同名 | `k ∝ spin / v²` |
| `baTraceArc` | 同名 | 圆周步进积分 |
| `baPowerLadder` | 同名 | N 档力度阶梯 |
| `baBestShot` | 同名 | 全球 × 全袋择优，`score` 含切角/距离/可行性惩罚 |
| `baHomographyFromCorners` | `baHomographyFromCorners`(Overlay 内) | DLT 8 元方程组 |
| `baScreenBallRadius` | 同名 | 局部微分估屏幕球半径 |
| `ba_rebind_symbols` | `ba_rebind_symbols` | 标准 fishhook（indirect symbol table） |

**切角定义**：本工程 `cutAngleDeg` 是 `ĉ` 与 `d̂` 的夹角原值，0–180°。
> 90° 表示母球在目标球正前方（打不到），实际有效击球是 0–82°。
> 如果你习惯“切角 0–90°”的台球术语，取 `min(cut, 180−cut)` 即为薄厚角。

---

## 7. 反检测

`antiDetection=1`（默认）时：

- ObjC 层 swizzle 6 处：`NSFileManager` 的
  `fileExistsAtPath:` / `isReadableFileAtPath:` / `attributesOfItemAtPath:error:` /
  `contentsOfDirectoryAtPath:error:` / `createFileAtPath:contents:attributes:`，
  以及 `UIApplication canOpenURL:`
- C 层 fishhook 绑定 7 个：`stat` `lstat` `access` `open` `fopen` `getenv` `_dyld_get_image_name`
- 隐藏路径 15 条：`/var/jb` `/Applications/Cydia.app` `/Applications/Sileo.app`
  `/Applications/Zebra.app` `/Library/MobileSubstrate` `/Library/PreferenceBundles`
  `/usr/sbin/sshd` `/usr/bin/ssh` `/bin/bash` `/bin/sh` `/etc/apt` `/private/preboot`
  `/usr/lib/libhooker` `/usr/lib/libsubstrate` `/usr/lib/libellekit`
- 隐藏关键词：`frida` `Frida` `cycript` `Substrate` `substrate` `BilliardsAim`
  `Cephei` `shepherd`
- `getenv` 抹掉 `DYLD_INSERT_LIBRARIES` `DYLD_FRAMEWORK_PATH` `_MSSafeMode` `_MSSuppressLogging`
- `_dyld_get_image_name` 对含自身名的镜像返回 NULL（游戏遍历 dyld 看不到本 dylib）

arm64e 上指针带 PAC，`BA_STRIP_PAC` 在替换前剥离签名位。

---

## 8. 故障排查

| 现象 | 原因 | 处理 |
|---|---|---|
| 启动闪退 | IPA 未脱壳 / 签名不全 | `ipainfo.sh` 看 `cryptid`；重跑 `resign.sh` |
| 无 HUD | 1.2s 后仍无 keyWindow，或注入失败 | `machoinject.py info` 确认有 `LC_LOAD_WEAK_DYLIB`；看 `NSLog [BA]` |
| HUD 有、无瞄准线 | 球数组偏移不对 | 点 `测绘`；或手动试 `stride` 16/20/24 |
| 瞄准线在台外 | 标定顺序错 | 重标，左上→右上→右下→左下 |
| 线位置整体偏移 | `coordMode` 填错 | 台面cm 填 0，屏幕pt 填 1 |
| 全部判“需加力” | `maxSpeed` 偏小或 `aimPower` 太小 | `maxSpeed` 提到 1200，`aimPower` 0.95 |
| `check` 报 padding 不足 | 目标 header 太挤 | 用 `insert_dylib --inplace`，或改注入到 `LC_LOAD_DYLIB` 尾部（需手工扩 `__TEXT`） |
| 日志看不到 `[BA]` | 设备 syslog 未开 | `idevicesyslog -p 进程名` 或 `os_log` |

调试开关：`autoProbeOnLaunch=1` 启动即测绘；`antiDetection=0` 关隐藏（排查时用）。

---

## 9. 注意事项

- 只对**你自己的 App / 离线包 / 私有靶场**做注入与重签。
- 每次改完二进制都要重签，否则 iOS 拒绝加载；`pack_ipa.sh` 已处理。
- 引擎参数与目标游戏的实际物理不一致时，瞄准线只准几何、不准力度 —— 先调 `tableLength`/
  `rollDecel`，再看力度百分比。
- `autoProbe` 是启发式，含噪声大的游戏可能给出次优解，此时以日志里 `probeScore` 最高的一组
  为基础手工微调。

---

产物与验证状态：
- `machoinject.py` 在真实 FAT 样本上完成注入自检，代码段/字符串段/数据段 **零字节改动**，FAT 重建后 `file` 仍正确识别双架构。
- `BAEngine.cpp` 通过 `g++ -Wall -Wextra` 语法校验，C 与 C++ 双模式均可包含 `BACommon.h`。
- 引擎 10 组功能断言（台面/袋口/直球切角/45°切球/库边/镜像/滚动距离/轨迹不越界/多球择优/翻袋/曲率单调/力度单调）全部通过。
- dylib 本体未在此环境编译（无 clang/iOS SDK），需在 macOS 执行 `build.sh`。
