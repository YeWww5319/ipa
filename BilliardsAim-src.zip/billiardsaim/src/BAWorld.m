// BAWorld.m — 内存扫描引擎
// 对应原版 BAWorld: start / setManualAddress: / moduleBase / scanCandidate / snapshot
#import "BAWorld.h"
#import "BAConfig.h"
#include <mach/mach.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <string.h>

#define MH_MAGIC_64_V 0xfeedfacf
#define LC_SEGMENT_64_V 0x19

@implementation BAWorld {
    uintptr_t _base;          // 模块基址
    uintptr_t _dataStart;     // __DATA 段起始
    uintptr_t _dataEnd;
    uintptr_t _manual;
    BAVec2    _balls[BA_MAX_BALLS];
    int       _count;
    BOOL      _valid;
    BOOL      _running;
}

+ (instancetype)shared {
    static BAWorld *g;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ g = [[BAWorld alloc] init]; });
    return g;
}

- (void)start {
    if (_running) return;
    _running = YES;
    [self scanCandidate];
    if (_base) [self snapshot];
}

- (void)stop { _running = NO; }

- (void)setManualAddress:(uintptr_t)addr {
    _manual = addr;
    if (addr) { _dataStart = addr; _dataEnd = addr + 0x200000; }
}

- (BOOL)valid { return _valid; }
- (int)ballCount { return _count; }
- (BAVec2)ballAt:(int)i { return (i >= 0 && i < _count) ? _balls[i] : BAV(0, 0); }
- (BAVec2)cueBall { return _count > 0 ? _balls[0] : BAV(0, 0); }

// ================= 镜像枚举 =================
- (NSArray<NSString *> *)listImages {
    NSMutableArray *a = [NSMutableArray array];
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; ++i) {
        const char *nm = _dyld_get_image_name(i);
        if (nm) [a addObject:[NSString stringWithUTF8String:nm]];
    }
    return a;
}

// 自动挑主模块: 跳过系统/系统库, 取体积最大的非系统模块
- (NSString *)autoDetectModule {
    uint32_t n = _dyld_image_count();
    NSString *best = nil;
    uint64_t bestSize = 0;

    for (uint32_t i = 0; i < n; ++i) {
        const char *nmc = _dyld_get_image_name(i);
        if (!nmc) continue;
        NSString *nm = [NSString stringWithUTF8String:nmc];
        if ([nm hasPrefix:@"/usr/lib/"] || [nm hasPrefix:@"/System/"] ||
            [nm hasPrefix:@"/var/jb/usr/lib/"] || [nm hasPrefix:@"/Developer/"]) continue;

        const struct mach_header_64 *h =
            (const struct mach_header_64 *)_dyld_get_image_header(i);
        if (!h || h->magic != MH_MAGIC_64_V) continue;

        // 累加 __TEXT fileoff=0 段的 vmsize 作为规模
        uint64_t sz = 0;
        const uint8_t *p = (const uint8_t *)h;
        uint32_t off = sizeof(struct mach_header_64);
        for (uint32_t c = 0; c < h->ncmds; ++c) {
            const struct load_command *lc = (const struct load_command *)(p + off);
            if (lc->cmdsize < 8) break;
            if (lc->cmd == LC_SEGMENT_64_V) {
                const struct segment_command_64 *sg = (const struct segment_command_64 *)lc;
                if (sg->fileoff == 0 && sg->filesize > 0) sz += sg->vmsize;
            }
            off += lc->cmdsize;
        }
        if (sz > bestSize) { bestSize = sz; best = [nm lastPathComponent]; }
    }
    return best;
}

// ================= 模块基址 =================
- (uintptr_t)moduleBase {
    if (_base) return _base;

    BAConfig *cfg = [BAConfig shared];
    NSString *want = cfg.moduleName;
    uint32_t n = _dyld_image_count();

    if (want.length == 0) {
        want = [self autoDetectModule];
        if (want.length) cfg.moduleName = want;
    }

    for (uint32_t i = 0; i < n; ++i) {
        const char *nmc = _dyld_get_image_name(i);
        if (!nmc) continue;
        NSString *nm = [NSString stringWithUTF8String:nmc];
        NSString *last = [nm lastPathComponent];

        BOOL hit = [last isEqualToString:want] || [last containsString:want] ||
                   [nm containsString:want];
        if (hit) {
            _base = (uintptr_t)_dyld_get_image_header(i);
            BAConfig *c = [BAConfig shared];
            if (c.moduleName.length == 0) c.moduleName = last;
            NSLog(@"[BA] module '%@' -> %p (slide=%ld)", last, (void *)_base,
                  (long)_dyld_get_image_vmaddr_slide(i));
            return _base;
        }
    }
    NSLog(@"[BA] module '%@' 未找到, 已加载 %u 个镜像", want, n);
    return 0;
}

// ================= 扫描 __DATA =================
- (BOOL)scanCandidate {
    if (_manual) { _dataStart = _manual; _dataEnd = _manual + 0x200000; return YES; }
    if (_dataStart) return YES;

    uintptr_t base = [self moduleBase];
    if (!base) return NO;

    const struct mach_header_64 *h = (const struct mach_header_64 *)base;
    if (h->magic != MH_MAGIC_64_V) {
        NSLog(@"[BA] %p 不是 Mach-O (magic=0x%08x)", (void *)base, h->magic);
        return NO;
    }

    uintptr_t lo = UINTPTR_MAX, hi = 0;
    const uint8_t *p = (const uint8_t *)h;
    uint32_t off = sizeof(struct mach_header_64);

    for (uint32_t c = 0; c < h->ncmds; ++c) {
        const struct load_command *lc = (const struct load_command *)(p + off);
        if (lc->cmdsize < 8) break;
        if (lc->cmd == LC_SEGMENT_64_V) {
            const struct segment_command_64 *sg = (const struct segment_command_64 *)lc;
            char segname[17] = {0};
            memcpy(segname, sg->segname, 16);
            // 只取可写数据段: __DATA / __DATA_CONST / __DATA_DIRTY
            if (strstr(segname, "__DATA") == segname) {
                uintptr_t s = base + sg->vmaddr;
                uintptr_t e = s + sg->vmsize;
                if (s < lo) lo = s;
                if (e > hi) hi = e;
            }
        }
        off += lc->cmdsize;
    }

    if (hi <= lo) { NSLog(@"[BA] 未找到 __DATA 段"); return NO; }
    _dataStart = lo;
    _dataEnd = hi;
    NSLog(@"[BA] __DATA 0x%lx - 0x%lx (%.1f MB)",
          (unsigned long)lo, (unsigned long)hi, (hi - lo) / 1048576.0);
    return YES;
}

// ================= 快照 =================
- (BOOL)snapshot {
    if (!_dataStart) { if (![self scanCandidate]) return NO; }

    BAConfig *cfg = [BAConfig shared];
    int stride = cfg.ballStride;
    if (stride < 8 || stride > 512) stride = 24;
    int want = cfg.ballCount;
    if (want < 1 || want > BA_MAX_BALLS) want = 16;

    int xOff = cfg.ballXOffset;
    int yOff = cfg.ballYOffset;
    BOOL isDouble = (cfg.ballValueType == 1);

    size_t chunk = 0x40000;                       // 256 KB
    uint8_t *buf = malloc(chunk);
    if (!buf) return NO;

    int found = 0;
    _count = 0;
    _valid = NO;

    uintptr_t addr = _dataStart;
    while (addr < _dataEnd && found < BA_MAX_BALLS) {
        mach_vm_size_t got = 0;
        kern_return_t kr = vm_read_overwrite(mach_task_self(), (mach_vm_address_t)addr,
                                             (mach_vm_size_t)chunk,
                                             (mach_vm_address_t)buf, &got);
        if (kr != KERN_SUCCESS || got < (mach_vm_size_t)stride) {
            addr += chunk;
            continue;
        }
        size_t usable = got;
        for (size_t o = 0; o + stride <= usable; o += stride) {
            double vx, vy;
            if (isDouble) {
                memcpy(&vx, buf + o + xOff, 8);
                memcpy(&vy, buf + o + yOff, 8);
            } else {
                float fx, fy;
                memcpy(&fx, buf + o + xOff, 4);
                memcpy(&fy, buf + o + yOff, 4);
                vx = fx; vy = fy;
            }
            if (isnan(vx) || isnan(vy) || isinf(vx) || isinf(vy)) continue;
            if (vx <= 0 || vy <= 0) continue;
            if (vx > 4000 || vy > 4000) continue;

            _balls[found] = BAV(vx, vy);
            if (++found >= BA_MAX_BALLS) break;
        }
        addr += got;
    }
    free(buf);

    _count = found;
    _valid = (found >= (want / 2) && found > 0);
    return _valid;
}

// ================= 偏移自动测绘 =================
// 思路: 对每组 (stride, xOff, type) 统计"看起来像球"的内存单元,
// 用 几何合理性(在台面内/互不重叠/数量匹配) 打分, 取最高分。
- (NSDictionary *)autoProbeWithTable:(BATable)table coordinate:(int)coordMode {
    if (![self scanCandidate]) return nil;

    const int strides[]  = {16, 20, 24, 28, 32, 36, 40, 44, 48, 56, 64, 72, 80, 96, 112, 128};
    const int offsets[]  = {0, 4, 8, 12, 16, 20, 24, 28, 32, 40, 48, 56, 64};
    const int ns = sizeof(strides) / sizeof(strides[0]);
    const int no = sizeof(offsets) / sizeof(offsets[0]);

    // 坐标量纲上限
    double limX, limY;
    switch (coordMode) {
        case 0: limX = table.length * 1.6; limY = table.width  * 1.6; break;
        case 1: limX = 2000; limY = 2000; break;
        default: limX = 1.6; limY = 1.6; break;
    }

    size_t chunk = 0x100000;                  // 1 MB 采样块
    uint8_t *buf = malloc(chunk);
    if (!buf) return nil;

    // 只采样前 12 MB, 避免卡死
    uintptr_t scanEnd = _dataStart + 12 * 1024 * 1024;
    if (scanEnd > _dataEnd) scanEnd = _dataEnd;

    NSMutableDictionary *bestCfg = nil;
    double bestScore = -1;

    for (int si = 0; si < ns; ++si) {
        int stride = strides[si];
        for (int oi = 0; oi < no; ++oi) {
            int xOff = offsets[oi];
            if (xOff + 8 > stride) continue;

            for (int ty = 0; ty < 2; ++ty) {
                BOOL isD = (ty == 1);
                int need = isD ? 8 : 4;
                if (xOff + need > stride) continue;
                int yOff = xOff + need;
                if (yOff + need > stride) continue;

                int hits = 0, overlaps = 0;
                double sumX = 0, sumY = 0;
                BAVec2 keep[BA_MAX_BALLS];
                int kn = 0;

                uintptr_t a = _dataStart;
                while (a < scanEnd) {
                    mach_vm_size_t got = 0;
                    if (vm_read_overwrite(mach_task_self(), (mach_vm_address_t)a,
                                          (mach_vm_size_t)chunk,
                                          (mach_vm_address_t)buf, &got) != KERN_SUCCESS)
                        break;
                    for (size_t o = 0; o + stride <= (size_t)got; o += stride) {
                        double vx, vy;
                        if (isD) {
                            memcpy(&vx, buf + o + xOff, 8);
                            memcpy(&vy, buf + o + yOff, 8);
                        } else {
                            float fx, fy;
                            memcpy(&fx, buf + o + xOff, 4);
                            memcpy(&fy, buf + o + yOff, 4);
                            vx = fx; vy = fy;
                        }
                        if (!isfinite(vx) || !isfinite(vy)) continue;
                        if (vx <= 0 || vy <= 0 || vx > limX || vy > limY) continue;
                        hits++;
                        sumX += vx; sumY += vy;
                        if (kn < BA_MAX_BALLS) {
                            // 重叠检测
                            for (int k = 0; k < kn; ++k) {
                                double dx = keep[k].x - vx, dy = keep[k].y - vy;
                                if (dx * dx + dy * dy < 1e-4) { overlaps++; break; }
                            }
                            keep[kn++] = BAV(vx, vy);
                        }
                    }
                    a += got;
                }

                if (hits < 3) continue;

                // 打分: 数量合理 + 分布不重叠 + 坐标离散度合适
                double sc = 0;
                sc += (hits <= 32) ? hits * 6.0 : (32 * 6.0 - (hits - 32) * 3.0);
                sc -= overlaps * 12.0;
                if (kn >= 3) {
                    double mx = sumX / kn, my = sumY / kn;
                    double var = 0;
                    for (int k = 0; k < kn; ++k) {
                        double dx = keep[k].x - mx, dy = keep[k].y - my;
                        var += dx * dx + dy * dy;
                    }
                    var /= kn;
                    sc += sqrt(var) * 0.8;         // 分散度加分
                }
                if ((int)hits == table.pocketCount) sc -= 50;  // 只碰巧命中袋口数, 可疑

                if (sc > bestScore) {
                    bestScore = sc;
                    bestCfg = [@{
                        @"ballStride": @(stride),
                        @"ballXOffset": @(xOff),
                        @"ballYOffset": @(yOff),
                        @"ballValueType": @(ty),
                        @"ballCount": @(hits > 32 ? 32 : hits),
                        @"coordMode": @(coordMode),
                        @"probeScore": @(sc),
                        @"probeHits": @(hits),
                    } mutableCopy];
                }
            }
        }
    }
    free(buf);

    if (bestCfg) {
        BAConfig *cfg = [BAConfig shared];
        cfg.ballStride    = [bestCfg[@"ballStride"] intValue];
        cfg.ballXOffset   = [bestCfg[@"ballXOffset"] intValue];
        cfg.ballYOffset   = [bestCfg[@"ballYOffset"] intValue];
        cfg.ballValueType = [bestCfg[@"ballValueType"] intValue];
        cfg.ballCount     = [bestCfg[@"ballCount"] intValue];
        [cfg save];
        NSLog(@"[BA] autoProbe 最优: %@", bestCfg);
    } else {
        NSLog(@"[BA] autoProbe 未找到可用配置");
    }
    return bestCfg;
}

@end
