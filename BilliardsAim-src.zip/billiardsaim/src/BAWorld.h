// BAWorld.h — 内存扫描引擎接口
#ifndef BA_WORLD_H
#define BA_WORLD_H

#import <Foundation/Foundation.h>
#include "BACommon.h"

#define BA_MAX_BALLS 32   // 与原版 objPath 容量 [32{?=dd}] 对齐

@interface BAWorld : NSObject

+ (instancetype)shared;

// 生命周期
- (void)start;
- (void)stop;

// 模块定位
- (uintptr_t)moduleBase;                       // 按 cfg.moduleName 匹配
- (NSString *)autoDetectModule;                // 自动挑主模块名
- (NSArray<NSString *> *)listImages;           // 调试: 列出全部已加载镜像

// 手动指定球数组基址
- (void)setManualAddress:(uintptr_t)addr;

// 扫描 + 快照
- (BOOL)scanCandidate;
- (BOOL)snapshot;                              // 读一帧, 结果存 lastBalls

// 结果读取
- (int)ballCount;                              // 有效球数
- (BAVec2)ballAt:(int)i;                       // 台面坐标
- (BAVec2)cueBall;                             // 母球 (首颗/白球)
- (BOOL)valid;

// ===== 偏移自动测绘 =====
// 遍历 stride/offset/type 组合, 用几何合理性打分, 返回最优配置并写入 plist
- (NSDictionary *)autoProbeWithTable:(BATable)table
                         coordinate:(int)coordMode;   // 0=台面cm 1=屏幕pt 2=归一化

@end

#endif
