// BAOverlay.m — 主控窗口 / 图层 / 四点标定 / 每帧绘制 / HUD
#import "BAOverlay.h"
#import "BAConfig.h"
#import "BAWorld.h"
#import <QuartzCore/QuartzCore.h>

// ================== 单应矩阵 ==================
typedef struct { double m[9]; } BAHomography;

// 解 n 元线性方程组 (高斯消元, 部分主元)
static BOOL solveLin(double *A, double *b, int n, double *x) {
    for (int i = 0; i < n; ++i) {
        int piv = i;
        for (int r = i + 1; r < n; ++r)
            if (fabs(A[r * n + i]) > fabs(A[piv * n + i])) piv = r;
        if (fabs(A[piv * n + i]) < 1e-12) return NO;
        if (piv != i) {
            for (int c = 0; c < n; ++c) {
                double t = A[i * n + c]; A[i * n + c] = A[piv * n + c]; A[piv * n + c] = t;
            }
            double t = b[i]; b[i] = b[piv]; b[piv] = t;
        }
        for (int r = i + 1; r < n; ++r) {
            double f = A[r * n + i] / A[i * n + i];
            if (f == 0) continue;
            for (int c = i; c < n; ++c) A[r * n + c] -= f * A[i * n + c];
            b[r] -= f * b[i];
        }
    }
    for (int i = n - 1; i >= 0; --i) {
        double s = b[i];
        for (int c = i + 1; c < n; ++c) s -= A[i * n + c] * x[c];
        x[i] = s / A[i * n + i];
    }
    return YES;
}

// 四点 -> 台面矩形 (0,0)-(L,W) 的投影矩阵
// 对应原版 baHomographyFromCorners
static BAHomography baHomographyFromCorners(CGPoint tl, CGPoint tr, CGPoint br,
                                            CGPoint bl, double L, double W) {
    BAHomography H; memset(&H, 0, sizeof(H));
    if (L <= 0) L = 1;
    if (W <= 0) W = 1;

    // 源(台)/目标(屏) 四对点: 台面 -> 屏幕
    double src[4][2] = {{0,0},{L,0},{L,W},{0,W}};
    CGPoint dst[4] = {tl, tr, br, bl};

    // 未知量 [a b c d e f g h], 方程组 8x8
    double A[64] = {0}, b[8] = {0};
    for (int i = 0; i < 4; ++i) {
        double X = src[i][0], Y = src[i][1];
        double u = dst[i].x,  v = dst[i].y;
        // u = (aX + bY + c) / (gX + hY + 1)
        int r = i * 2;
        A[r*8+0]=X; A[r*8+1]=Y; A[r*8+2]=1; A[r*8+6]=-X*u; A[r*8+7]=-Y*u; b[r]=u;
        // v = (dX + eY + f) / (gX + hY + 1)
        r = i * 2 + 1;
        A[r*8+3]=X; A[r*8+4]=Y; A[r*8+5]=1; A[r*8+6]=-X*v; A[r*8+7]=-Y*v; b[r]=v;
    }
    double x[8] = {0};
    if (!solveLin(A, b, 8, x)) return H;

    H.m[0]=x[0]; H.m[1]=x[1]; H.m[2]=x[2];
    H.m[3]=x[3]; H.m[4]=x[4]; H.m[5]=x[5];
    H.m[6]=x[6]; H.m[7]=x[7]; H.m[8]=1.0;
    (void)L; (void)W;
    return H;
}

static CGPoint baTableToScreen(BAHomography H, BAVec2 p) {
    double w = H.m[6]*p.x + H.m[7]*p.y + H.m[8];
    if (fabs(w) < 1e-12) w = 1e-12;
    return CGPointMake((H.m[0]*p.x + H.m[1]*p.y + H.m[2]) / w,
                       (H.m[3]*p.x + H.m[4]*p.y + H.m[5]) / w);
}

// 球半径在屏幕上的像素值: 用局部微分近似
static double baScreenBallRadius(BAHomography H, double r, BAVec2 at) {
    CGPoint c = baTableToScreen(H, at);
    CGPoint dx = baTableToScreen(H, BAV(2 * r, 0));
    CGPoint dy = baTableToScreen(H, BAV(0, 2 * r));
    double a = hypot(dx.x - c.x, dx.y - c.y) * 0.5;
    double b = hypot(dy.x - c.x, dy.y - c.y) * 0.5;
    return (a + b) * 0.5;
}

// ================== Overlay ==================
@implementation BAOverlay {
    UIWindow        *_win;
    UIView          *_root;
    CAShapeLayer    *_aimLayer;     // 母球路径
    CAShapeLayer    *_objLayer;     // 目标球路径
    CAShapeLayer    *_ghostLayer;   // 虚拟球
    CAShapeLayer    *_bankLayer;    // 翻袋镜像线
    CATextLayer     *_textLayer;    // 切角/力度文字
    UIButton        *_btnCalib;
    UIButton        *_btnToggle;
    UIButton        *_btnBank;
    UIButton        *_btnProbe;

    CADisplayLink   *_link;
    BAHomography     _H;
    BOOL             _hasH;
    BOOL             _visible;
    BOOL             _calibrating;
    NSMutableArray  *_calibPts;

    // 帧间平滑
    BAVec2           _lastGhost;
    BOOL             _hasLast;
}

+ (instancetype)shared {
    static BAOverlay *g;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ g = [[BAOverlay alloc] init]; });
    return g;
}

- (instancetype)init {
    if ((self = [super init])) {
        _visible = YES;
        _calibPts = [NSMutableArray array];
    }
    return self;
}

// ================== 挂载 ==================
- (void)attach {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self buildWindows];
        [self buildLayers];
        [self rebuildHomography];
        [self startLink];
    });
}

- (void)detach {
    [_link invalidate];
    _link = nil;
    [_win removeFromSuperview];
    _win = nil;
}

- (void)buildWindows {
    UIWindow *key = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { key = w; break; }
    }
    CGRect screen = [UIScreen mainScreen].bounds;

    _win = [[UIWindow alloc] initWithFrame:screen];
    _win.windowLevel = UIWindowLevelAlert + 1;
    _win.backgroundColor = [UIColor clearColor];
    _win.userInteractionEnabled = NO;
    _win.hidden = NO;

    _root = [[UIView alloc] initWithFrame:screen];
    _root.backgroundColor = [UIColor clearColor];
    _root.userInteractionEnabled = NO;
    [_win addSubview:_root];

    // 让 window 能显示但不抢触摸
    if (@available(iOS 13.0, *)) {
        _win.windowScene = key.windowScene;
    }
    [_win makeKeyAndVisible];
    // 立刻把 key 还给游戏窗口, 避免影响输入
    [key makeKeyWindow];

    // 悬浮 HUD 按钮 (这几个需要触摸)
    CGFloat s = 44, y0 = 90;
    _btnCalib  = [self makeBtn:@"标定" y:y0       action:@selector(onCalib)];
    _btnToggle = [self makeBtn:@"显示" y:y0 + s+6 action:@selector(onToggle)];
    _btnBank   = [self makeBtn:@"翻袋" y:y0+2*(s+6) action:@selector(onBank)];
    _btnProbe  = [self makeBtn:@"测绘" y:y0+3*(s+6) action:@selector(onProbe)];
    for (UIButton *b in @[_btnCalib, _btnToggle, _btnBank, _btnProbe]) {
        b.frame = CGRectMake(screen.size.width - s - 8, b.frame.origin.y, s, s);
        [_root addSubview:b];
    }
    _root.userInteractionEnabled = YES;
    NSLog(@"[BA] overlay attached, screen=%@", NSStringFromCGRect(screen));
}

- (UIButton *)makeBtn:(NSString *)t y:(CGFloat)y action:(SEL)sel {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = CGRectMake(0, y, 44, 44);
    [b setTitle:t forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    b.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.45];
    b.layer.cornerRadius = 8;
    [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [b addTarget:self action:sel forControlEvents:UIControlEventTouchUpInside];
    return b;
}

- (CAShapeLayer *)newLayer:(UIColor *)c width:(CGFloat)w dashed:(BOOL)dashed {
    CAShapeLayer *l = [CAShapeLayer layer];
    l.strokeColor = c.CGColor;
    l.fillColor = [UIColor clearColor].CGColor;
    l.lineWidth = w;
    l.lineCap = kCALineCapRound;
    l.lineJoin = kCALineJoinRound;
    if (dashed) {
        l.lineDashPattern = @[@6, @4];
    }
    return l;
}

- (void)buildLayers {
    CGFloat sw = [UIScreen mainScreen].bounds.size.width;

    _bankLayer  = [self newLayer:[[UIColor orangeColor] colorWithAlphaComponent:0.75] width:1.2 dashed:YES];
    _objLayer   = [self newLayer:[[UIColor cyanColor] colorWithAlphaComponent:0.9]   width:2.0 dashed:NO];
    _aimLayer   = [self newLayer:[[UIColor yellowColor] colorWithAlphaComponent:0.95] width:2.5 dashed:NO];
    _ghostLayer = [self newLayer:[[UIColor whiteColor] colorWithAlphaComponent:0.85] width:1.5 dashed:YES];

    _textLayer = [CATextLayer layer];
    _textLayer.contentsScale = [UIScreen mainScreen].scale;
    _textLayer.font = (__bridge CFTypeRef)[UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightMedium];
    _textLayer.fontSize = 12;
    _textLayer.alignmentMode = kCAAlignmentLeft;
    _textLayer.foregroundColor = [UIColor whiteColor].CGColor;
    _textLayer.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.35].CGColor;
    _textLayer.frame = CGRectMake(8, 120, sw * 0.72, 20);
    _textLayer.string = @"";

    for (CALayer *l in @[_bankLayer, _objLayer, _aimLayer, _ghostLayer, _textLayer]) {
        [_root.layer addSublayer:l];
    }
}

- (void)toggleVisible {
    _visible = !_visible;
    for (CALayer *l in @[_bankLayer, _objLayer, _aimLayer, _ghostLayer, _textLayer]) {
        l.hidden = !_visible;
    }
    for (UIButton *b in @[_btnCalib, _btnBank, _btnProbe]) {
        b.hidden = !_visible;
    }
}

// ================== 标定 ==================
- (void)startCalibration {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self->_calibPts removeAllObjects];
        self->_calibrating = YES;
        self->_textLayer.string = @"标定: 依次点 左上 → 右上 → 右下 → 左下";
        NSLog(@"[BA] 开始标定");

        // 单击取点: 每次点击记录一个角点, 满 4 个自动结束
        for (UIGestureRecognizer *g in [self->_root.gestureRecognizers copy]) {
            [self->_root removeGestureRecognizer:g];
        }
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                       initWithTarget:self action:@selector(onCalibTap:)];
        tap.numberOfTapsRequired = 1;
        [self->_root addGestureRecognizer:tap];
    });
}

- (void)onCalibTap:(UITapGestureRecognizer *)g {
    if (!_calibrating) return;
    CGPoint p = [g locationInView:_root];
    [_calibPts addObject:[NSValue valueWithCGPoint:p]];
    _textLayer.string = [NSString stringWithFormat:@"标定 %lu/4", (unsigned long)_calibPts.count];

    if (_calibPts.count >= 4) {
        _calibrating = NO;
        [self finishCalibrationWithPoints:_calibPts];
    }
}

- (void)finishCalibrationWithPoints:(NSArray<NSValue *> *)pts {
    if (pts.count < 4) return;
    BAConfig *cfg = [BAConfig shared];
    cfg.cornerTL = [pts[0] CGPointValue];
    cfg.cornerTR = [pts[1] CGPointValue];
    cfg.cornerBR = [pts[2] CGPointValue];
    cfg.cornerBL = [pts[3] CGPointValue];
    cfg.screenSize = [UIScreen mainScreen].bounds.size;
    cfg.calibrated = YES;
    [cfg save];
    [self rebuildHomography];
    NSLog(@"[BA] 标定完成 TL=%@ TR=%@ BR=%@ BL=%@",
          NSStringFromCGPoint(cfg.cornerTL), NSStringFromCGPoint(cfg.cornerTR),
          NSStringFromCGPoint(cfg.cornerBR), NSStringFromCGPoint(cfg.cornerBL));
}

- (void)rebuildHomography {
    BAConfig *cfg = [BAConfig shared];
    if (!cfg.calibrated) {
        // 未标定: 用屏幕 88% 区域当台面, 至少能出线
        CGRect r = [UIScreen mainScreen].bounds;
        CGFloat iw = r.size.width * 0.06, ih = r.size.height * 0.12;
        _H = baHomographyFromCorners(
                CGPointMake(iw, ih),
                CGPointMake(r.size.width - iw, ih),
                CGPointMake(r.size.width - iw, r.size.height - ih),
                CGPointMake(iw, r.size.height - ih),
                cfg.tableLength, cfg.tableWidth);
        _hasH = YES;
        return;
    }
    BATable t = [cfg table];
    _H = baHomographyFromCorners(cfg.cornerTL, cfg.cornerTR, cfg.cornerBR, cfg.cornerBL,
                                 t.length, t.width);
    _hasH = YES;
    NSLog(@"[BA] 单应矩阵重建完成");
}

// ================== 帧驱动 ==================
- (void)startLink {
    [_link invalidate];
    _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick)];
    BAConfig *cfg = [BAConfig shared];
    NSInteger hz = cfg.refreshHz;
    if (hz < 30) hz = 30;
    if (hz > 120) hz = 120;
    _link.preferredFramesPerSecond = hz;
    [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    NSLog(@"[BA] displayLink 已启动 %ld Hz", (long)hz);
}

- (void)clearAll {
    _aimLayer.path = nil;
    _objLayer.path = nil;
    _ghostLayer.path = nil;
    _bankLayer.path = nil;
    _textLayer.string = @"";
}

- (void)tick {
    if (!_visible) return;
    if (!_hasH) [self rebuildHomography];

    BAConfig *cfg = [BAConfig shared];
    BAWorld *w = [BAWorld shared];
    if (![w snapshot] || [w ballCount] < 2) { [self clearAll]; return; }

    BATable t = [cfg table];
    int n = [w ballCount];
    BAVec2 cue = [w cueBall];

    // 把其余球组成数组
    BAVec2 balls[BA_MAX_BALLS];
    int idx[BA_MAX_BALLS];
    int m = 0;
    for (int i = 1; i < n && m < BA_MAX_BALLS; ++i) {
        balls[m] = [w ballAt:i];
        idx[m] = i;
        m++;
    }
    if (m == 0) { [self clearAll]; return; }

    // 求解
    BAResult best; memset(&best, 0, sizeof(best));
    best.score = -1e9;
    BOOL gotNormal = NO;

    if (baBestShot(t, cue, balls, m, idx, baPocketCount(t), cfg.aimPower, &best)) {
        gotNormal = YES;
    }

    // 翻袋
    if (cfg.showBank && m > 0) {
        for (int b = 0; b < m; ++b) {
            for (int p = 0; p < baPocketCount(t); ++p) {
                BAResult rb;
                if (baBestBank(t, cue, balls[b], baPocketAt(t, p),
                               cfg.bankBounces, cfg.aimPower, &rb)) {
                    rb.ballIndex = idx[b];
                    rb.pocketIndex = p;
                    if (rb.score > best.score || !gotNormal) { best = rb; gotNormal = YES; }
                }
            }
        }
    }

    // 扎杆
    if (cfg.showMasse && m > 0) {
        BAVec2 pk[6];
        for (int p = 0; p < baPocketCount(t); ++p) pk[p] = baPocketAt(t, p);
        BAResult rm;
        if (baSolveMasse(t, cue, balls[0], cfg.spinV, pk, baPocketCount(t),
                         cfg.aimPower, &rm)) {
            rm.ballIndex = idx[0];
            if (rm.score > best.score) best = rm;
        }
    }

    if (!best.valid) { [self clearAll]; return; }

    // ---- 绘制 ----
    [self drawAim:best cue:cue balls:balls count:m table:t cfg:cfg];
}

- (void)drawAim:(BAResult)r cue:(BAVec2)cue balls:(BAVec2 *)balls
          count:(int)n table:(BATable)t cfg:(BAConfig *)cfg {

    // 从结果里取目标球: ballIndex 是原始索引(1-based), 映射到 balls[0..n-1]
    BAVec2 target = balls[0];
    if (r.ballIndex >= 1 && r.ballIndex <= n && (r.ballIndex - 1) < n) {
        target = balls[r.ballIndex - 1];
    }

    BAVec2 pocket = baPocketAt(t, r.pocketIndex);

    // 母球路径
    if (cfg.showCuePath) {
        UIBezierPath *p = [UIBezierPath bezierPath];
        CGPoint a = baTableToScreen(_H, cue);
        CGPoint b = baTableToScreen(_H, r.result.ghost);
        [p moveToPoint:a];
        [p addLineToPoint:b];
        _aimLayer.path = p.CGPath;
    } else {
        _aimLayer.path = nil;
    }

    // 目标球路径
    if (cfg.showObjectPath && r.result.objPathCount >= 2) {
        UIBezierPath *p = [UIBezierPath bezierPath];
        [p moveToPoint:baTableToScreen(_H, r.result.objPath[0])];
        for (int i = 1; i < r.result.objPathCount; ++i)
            [p addLineToPoint:baTableToScreen(_H, r.result.objPath[i])];
        _objLayer.path = p.CGPath;
    } else {
        _objLayer.path = nil;
    }

    // 虚拟球
    if (cfg.showGhostBall) {
        CGPoint g = baTableToScreen(_H, r.result.ghost);
        double rad = baScreenBallRadius(_H, t.ballRadius, r.result.ghost);
        if (rad < 3) rad = 3;
        UIBezierPath *p = [UIBezierPath bezierPathWithArcCenter:g radius:rad
                                                         startAngle:0 endAngle:M_PI * 2
                                                          clockwise:YES];
        _ghostLayer.path = p.CGPath;
    } else {
        _ghostLayer.path = nil;
    }

    // 翻袋线
    if (cfg.showBank && r.result.bounces > 0 && r.result.objPathCount >= 3) {
        UIBezierPath *p = [UIBezierPath bezierPath];
        [p moveToPoint:baTableToScreen(_H, r.result.objPath[0])];
        [p addLineToPoint:baTableToScreen(_H, r.result.objPath[1])];
        [p addLineToPoint:baTableToScreen(_H, r.result.objPath[2])];
        _bankLayer.path = p.CGPath;
    } else {
        _bankLayer.path = nil;
    }

    // 文字
    if (cfg.showAimLine) {
        NSString *txt = [NSString stringWithFormat:
            @"%@ 切角%.1f° 力度%.0f%% 库%d %@",
            r.result.feasible ? @"可进" : @"风险",
            r.result.cutAngleDeg,
            cfg.aimPower * 100,
            r.result.bounces,
            r.result.feasible ? @"" : @"(需加力)"];
        _textLayer.string = txt;
        _textLayer.frame = CGRectMake(8, 96,
            [UIScreen mainScreen].bounds.size.width * 0.74, 20);
    }
}

// ================== HUD 回调 ==================
- (void)onCalib  { [self startCalibration]; }
- (void)onToggle { [self toggleVisible]; }

- (void)onBank {
    BAConfig *cfg = [BAConfig shared];
    cfg.showBank = !cfg.showBank;
    [cfg save];
    [_btnBank setTitle:cfg.showBank ? @"翻袋" : @"关袋" forState:UIControlStateNormal];
}

- (void)onProbe {
    BAConfig *cfg = [BAConfig shared];
    [_btnProbe setTitle:@"…" forState:UIControlStateNormal];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSDictionary *r = [[BAWorld shared] autoProbeWithTable:[cfg table]
                                                    coordinate:cfg.coordMode];
        dispatch_async(dispatch_get_main_queue(), ^{
            self->_btnProbe.titleLabel.font = [UIFont systemFontOfSize:9];
            [self->_btnProbe setTitle:(r ? @"已存" : @"失败") forState:UIControlStateNormal];
            [self rebuildHomography];
        });
    });
}

@end
