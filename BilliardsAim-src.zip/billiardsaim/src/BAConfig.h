// BAConfig.h — 配置单例
#ifndef BA_CONFIG_H
#define BA_CONFIG_H

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#include "BACommon.h"

@interface BAConfig : NSObject

+ (instancetype)shared;

@property (nonatomic, copy)   NSString *configPath;
- (void)load;
- (void)save;

// ---- 物理台面 ----
@property (nonatomic, assign) double tableLength;
@property (nonatomic, assign) double tableWidth;
@property (nonatomic, assign) double ballRadius;
@property (nonatomic, assign) double rollDecel;
@property (nonatomic, assign) double cushionRest;
@property (nonatomic, assign) double maxSpeed;
@property (nonatomic, assign) double pocketRadius;

// ---- 目标内存布局 ----
@property (nonatomic, copy)   NSString *moduleName;     // 目标模块名
@property (nonatomic, assign) long long ballArrayOffset;
@property (nonatomic, assign) int    ballCount;
@property (nonatomic, assign) int    ballStride;
@property (nonatomic, assign) int    ballXOffset;
@property (nonatomic, assign) int    ballYOffset;
@property (nonatomic, assign) int    ballValueType;     // 0=float 1=double
@property (nonatomic, assign) int    coordMode;         // 0=cm 1=pt 2=归一化

// ---- 标定 ----
@property (nonatomic, assign) BOOL     calibrated;
@property (nonatomic, assign) CGPoint  cornerTL;
@property (nonatomic, assign) CGPoint  cornerTR;
@property (nonatomic, assign) CGPoint  cornerBR;
@property (nonatomic, assign) CGPoint  cornerBL;
@property (nonatomic, assign) CGSize   screenSize;

// ---- 功能开关 ----
@property (nonatomic, assign) BOOL showAimLine;
@property (nonatomic, assign) BOOL showGhostBall;
@property (nonatomic, assign) BOOL showObjectPath;
@property (nonatomic, assign) BOOL showCuePath;
@property (nonatomic, assign) BOOL showPowerLadder;
@property (nonatomic, assign) BOOL antiDetection;
@property (nonatomic, assign) BOOL showBank;
@property (nonatomic, assign) BOOL showMasse;
@property (nonatomic, assign) BOOL autoProbeOnLaunch;
@property (nonatomic, assign) int  refreshHz;
@property (nonatomic, assign) int  bankBounces;
@property (nonatomic, assign) double aimPower;
@property (nonatomic, assign) double spinV;
@property (nonatomic, assign) double spinS;

// 导出为引擎用的台面结构
- (BATable)table;

@end

#endif
