// BAConfig.m
#import "BAConfig.h"

static NSString *const kDefaultPrefs = @"/var/mobile/Library/Preferences/com.zaka.billiardsaim.plist";
static NSString *const kFallbackPrefs = @"/var/mobile/Library/Preferences/com.ba.billiardsaim.plist";

@implementation BAConfig

+ (instancetype)shared {
    static BAConfig *g;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ g = [[BAConfig alloc] init]; });
    return g;
}

- (instancetype)init {
    if ((self = [super init])) {
        [self setDefaults];
        _configPath = kDefaultPrefs;
        [self load];
    }
    return self;
}

- (void)setDefaults {
    BATable t = baDefaultTable();
    _tableLength   = t.length;
    _tableWidth    = t.width;
    _ballRadius    = t.ballRadius;
    _rollDecel     = t.rollDecel;
    _cushionRest   = t.cushionRest;
    _maxSpeed      = t.maxSpeed;
    _pocketRadius  = t.pocketRadius;

    _moduleName       = @"";
    _ballArrayOffset  = 0;
    _ballCount        = 16;
    _ballStride       = 24;
    _ballXOffset      = 0;
    _ballYOffset      = 8;
    _ballValueType    = 1;     // double
    _coordMode        = 0;     // 台面 cm

    _calibrated = NO;
    _cornerTL = CGPointZero;
    _cornerTR = CGPointZero;
    _cornerBR = CGPointZero;
    _cornerBL = CGPointZero;
    _screenSize = CGSizeZero;

    _showAimLine      = YES;
    _showGhostBall    = YES;
    _showObjectPath   = YES;
    _showCuePath      = YES;
    _showPowerLadder  = YES;
    _antiDetection    = YES;
    _showBank         = NO;
    _showMasse        = NO;
    _autoProbeOnLaunch= NO;
    _refreshHz        = 60;
    _bankBounces      = 1;
    _aimPower         = 0.85;
    _spinV            = 0.0;
    _spinS            = 0.0;
}

// ================= plist =================
- (void)load {
    NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:_configPath];
    if (!d) {
        d = [NSDictionary dictionaryWithContentsOfFile:kFallbackPrefs];
        if (d) _configPath = kFallbackPrefs;
    }
    if (!d) {
        NSLog(@"[BA] 无配置文件, 使用默认值, 将写入 %@", _configPath);
        [self save];
        return;
    }

#define RD_D(k, p)  if (d[@#k]) _##p = [d[@#k] doubleValue]
#define RD_I(k, p)  if (d[@#k]) _##p = [d[@#k] intValue]
#define RD_B(k, p)  if (d[@#k]) _##p = [d[@#k] boolValue]
#define RD_S(k, p)  if (d[@#k]) _##p = [d[@#k] description]

    RD_D(tableLength,  tableLength);
    RD_D(tableWidth,   tableWidth);
    RD_D(ballRadius,   ballRadius);
    RD_D(rollDecel,    rollDecel);
    RD_D(cushionRest,  cushionRest);
    RD_D(maxSpeed,     maxSpeed);
    RD_D(pocketRadius, pocketRadius);

    RD_S(moduleName,      moduleName);
    RD_I(ballStride,      ballStride);
    RD_I(ballCount,       ballCount);
    RD_I(ballXOffset,     ballXOffset);
    RD_I(ballYOffset,     ballYOffset);
    RD_I(ballValueType,   ballValueType);
    RD_I(coordMode,       coordMode);
    if (d[@"ballArrayOffset"]) _ballArrayOffset = [d[@"ballArrayOffset"] longLongValue];

    RD_B(calibrated, calibrated);
    if (d[@"cornerTL"]) _cornerTL = CGPointFromString(d[@"cornerTL"]);
    if (d[@"cornerTR"]) _cornerTR = CGPointFromString(d[@"cornerTR"]);
    if (d[@"cornerBR"]) _cornerBR = CGPointFromString(d[@"cornerBR"]);
    if (d[@"cornerBL"]) _cornerBL = CGPointFromString(d[@"cornerBL"]);
    if (d[@"screenSize"]) _screenSize = CGSizeFromString(d[@"screenSize"]);

    RD_B(showAimLine,      showAimLine);
    RD_B(showGhostBall,    showGhostBall);
    RD_B(showObjectPath,   showObjectPath);
    RD_B(showCuePath,      showCuePath);
    RD_B(showPowerLadder,  showPowerLadder);
    RD_B(antiDetection,    antiDetection);
    RD_B(showBank,         showBank);
    RD_B(showMasse,        showMasse);
    RD_B(autoProbeOnLaunch, autoProbeOnLaunch);
    RD_I(refreshHz,        refreshHz);
    RD_I(bankBounces,      bankBounces);
    RD_D(aimPower,         aimPower);
    RD_D(spinV,            spinV);
    RD_D(spinS,            spinS);

#undef RD_D
#undef RD_I
#undef RD_B
#undef RD_S

    NSLog(@"[BA] 配置载入: module=%@ stride=%d x=%d y=%d type=%d",
          _moduleName, _ballStride, _ballXOffset, _ballYOffset, _ballValueType);
}

- (void)save {
    NSMutableDictionary *d = [NSMutableDictionary dictionary];
    d[@"tableLength"]  = @(_tableLength);
    d[@"tableWidth"]   = @(_tableWidth);
    d[@"ballRadius"]   = @(_ballRadius);
    d[@"rollDecel"]    = @(_rollDecel);
    d[@"cushionRest"]  = @(_cushionRest);
    d[@"maxSpeed"]     = @(_maxSpeed);
    d[@"pocketRadius"] = @(_pocketRadius);

    d[@"moduleName"]      = _moduleName ?: @"";
    d[@"ballArrayOffset"] = @(_ballArrayOffset);
    d[@"ballCount"]       = @(_ballCount);
    d[@"ballStride"]      = @(_ballStride);
    d[@"ballXOffset"]     = @(_ballXOffset);
    d[@"ballYOffset"]     = @(_ballYOffset);
    d[@"ballValueType"]   = @(_ballValueType);
    d[@"coordMode"]       = @(_coordMode);

    d[@"calibrated"] = @(_calibrated);
    d[@"cornerTL"]   = NSStringFromCGPoint(_cornerTL);
    d[@"cornerTR"]   = NSStringFromCGPoint(_cornerTR);
    d[@"cornerBR"]   = NSStringFromCGPoint(_cornerBR);
    d[@"cornerBL"]   = NSStringFromCGPoint(_cornerBL);
    d[@"screenSize"] = NSStringFromCGSize(_screenSize);

    d[@"showAimLine"]       = @(_showAimLine);
    d[@"showGhostBall"]     = @(_showGhostBall);
    d[@"showObjectPath"]    = @(_showObjectPath);
    d[@"showCuePath"]       = @(_showCuePath);
    d[@"showPowerLadder"]   = @(_showPowerLadder);
    d[@"antiDetection"]     = @(_antiDetection);
    d[@"showBank"]          = @(_showBank);
    d[@"showMasse"]         = @(_showMasse);
    d[@"autoProbeOnLaunch"] = @(_autoProbeOnLaunch);
    d[@"refreshHz"]         = @(_refreshHz);
    d[@"bankBounces"]       = @(_bankBounces);
    d[@"aimPower"]          = @(_aimPower);
    d[@"spinV"]             = @(_spinV);
    d[@"spinS"]             = @(_spinS);

    NSString *dir = [_configPath stringByDeletingLastPathComponent];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir
                              withIntermediateDirectories:YES
                                               attributes:nil error:nil];
    [d writeToFile:_configPath atomically:YES];
}

- (BATable)table {
    BATable t;
    t.length       = _tableLength;
    t.width        = _tableWidth;
    t.ballRadius   = _ballRadius;
    t.rollDecel    = _rollDecel;
    t.cushionRest  = _cushionRest;
    t.maxSpeed     = _maxSpeed;
    t.pocketRadius = _pocketRadius;
    t.pocketCount  = 6;
    return t;
}

@end
