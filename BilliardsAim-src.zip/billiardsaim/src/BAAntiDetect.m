// BAAntiDetect.m — 越狱痕迹隐藏
// C 层: 标准 fishhook (indirect symbol table 重绑定 __la_symbol_ptr / __got)
// ObjC 层: method_exchangeImplementations (与原版一致)
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <mach-o/dyld.h>
#import <mach-o/loader.h>
#import <mach-o/nlist.h>
#import <string.h>
#import <stdlib.h>
#import <stdio.h>
#import <stdarg.h>
#import <fcntl.h>
#import <sys/stat.h>
#import <unistd.h>
#import <dlfcn.h>
#import <errno.h>

#import "BAConfig.h"

// ==================== 隐藏清单 ====================
static const char *kHiddenPaths[] = {
    "/var/jb",
    "/Applications/Cydia.app",
    "/Applications/Sileo.app",
    "/Applications/Zebra.app",
    "/Library/MobileSubstrate",
    "/Library/PreferenceBundles",
    "/usr/sbin/sshd",
    "/usr/bin/ssh",
    "/bin/bash",
    "/bin/sh",
    "/etc/apt",
    "/private/preboot",
    "/usr/lib/libhooker",
    "/usr/lib/libsubstrate",
    "/usr/lib/libellekit",
    NULL
};

static const char *kHiddenSubstr[] = {
    "frida", "Frida", "cycript",
    "Substrate", "substrate",
    "BilliardsAim", "BilliardsAim2",
    "Cephei", "shepherd",
    NULL
};

static BOOL ba_pathHidden(const char *path) {
    if (!path) return NO;
    for (int i = 0; kHiddenPaths[i]; ++i) {
        if (strncmp(path, kHiddenPaths[i], strlen(kHiddenPaths[i])) == 0) return YES;
    }
    for (int i = 0; kHiddenSubstr[i]; ++i) {
        if (strstr(path, kHiddenSubstr[i])) return YES;
    }
    return NO;
}

// ==================== fishhook ====================
struct ba_rebinding {
    const char *name;
    void      *replacement;
    void     **replaced;
};

#define BA_MAX_REBIND 32

#if defined(__arm64e__)
#define BA_STRIP_PAC(p) ((void *)((uintptr_t)(p) & 0x0000000FFFFFFFFFULL))
#else
#define BA_STRIP_PAC(p) (p)
#endif

// 在单个镜像里把符号名匹配的槽替换掉
static void ba_rebind_in_image(const struct mach_header_64 *h, intptr_t slide,
                               struct ba_rebinding *rebs, size_t count,
                               struct ba_rebinding *found, size_t *foundCount) {
    const struct symtab_command  *symtab = NULL;
    const struct dysymtab_command *dysym = NULL;

    const uint8_t *p = (const uint8_t *)h;
    uint32_t off = sizeof(struct mach_header_64);
    for (uint32_t c = 0; c < h->ncmds; ++c) {
        const struct load_command *lc = (const struct load_command *)(p + off);
        if (lc->cmdsize < 8) break;
        if (lc->cmd == LC_SYMTAB)       symtab = (const struct symtab_command *)lc;
        else if (lc->cmd == LC_DYSYMTAB) dysym = (const struct dysymtab_command *)lc;
        off += lc->cmdsize;
    }
    if (!symtab || !dysym) return;

    const struct nlist_64 *syms = (const struct nlist_64 *)((uintptr_t)h + symtab->symoff);
    const char *strtab = (const char *)((uintptr_t)h + symtab->stroff);
    const uint32_t *indirect = (const uint32_t *)((uintptr_t)h + dysym->indirectsymoff);

    // 遍历所有段, 找 __la_symbol_ptr / __got / __auth_got
    off = sizeof(struct mach_header_64);
    for (uint32_t c = 0; c < h->ncmds; ++c) {
        const struct load_command *lc = (const struct load_command *)(p + off);
        if (lc->cmdsize < 8) break;
        if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *sg = (const struct segment_command_64 *)lc;
            const struct section_64 *sect = (const struct section_64 *)(sg + 1);
            for (uint32_t s = 0; s < sg->nsects; ++s, ++sect) {
                char sectname[17] = {0};
                memcpy(sectname, sect->sectname, 16);
                BOOL isLazy = (strcmp(sectname, "__la_symbol_ptr") == 0);
                BOOL isGot  = (strcmp(sectname, "__got") == 0) ||
                              (strcmp(sectname, "__auth_got") == 0);
                if (!isLazy && !isGot) continue;

                void **slots = (void **)((uintptr_t)h + sect->offset);
                uint32_t nslots = (uint32_t)(sect->size / sizeof(void *));
                // reserved1 = indirect symbol table 起始索引
                for (uint32_t i = 0; i < nslots; ++i) {
                    uint32_t symidx = indirect[sect->reserved1 + i];
                    if (symidx == INDIRECT_SYMBOL_LOCAL || symidx == INDIRECT_SYMBOL_ABS)
                        continue;
                    if (symidx >= symtab->nsyms) continue;
                    const char *nm = strtab + syms[symidx].n_un.n_strx;
                    if (!nm || nm[0] != '_') continue;
                    nm++;   // 跳过前导下划线

                    for (size_t r = 0; r < count; ++r) {
                        if (strcmp(nm, rebs[r].name) != 0) continue;
                        void *cur = BA_STRIP_PAC(slots[i]);
                        // 首次命中时记录原函数
                        if (*rebs[r].replaced == NULL && cur) {
                            *rebs[r].replaced = cur;
                        }
                        if (cur == rebs[r].replacement) break;
                        slots[i] = rebs[r].replacement;
                        if (found && foundCount && *foundCount < BA_MAX_REBIND) {
                            found[*foundCount] = rebs[r];
                            (*foundCount)++;
                        }
                        break;
                    }
                }
            }
        }
        off += lc->cmdsize;
    }
}

static int ba_rebind_symbols(struct ba_rebinding *rebs, size_t count) {
    if (!rebs || !count) return 0;
    int total = 0;
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; ++i) {
        const struct mach_header_64 *h =
            (const struct mach_header_64 *)_dyld_get_image_header(i);
        if (!h || h->magic != 0xfeedfacf) continue;
        intptr_t slide = _dyld_get_image_vmaddr_slide(i);
        struct ba_rebinding found[BA_MAX_REBIND];
        size_t fc = 0;
        ba_rebind_in_image(h, slide, rebs, count, found, &fc);
        total += (int)fc;
    }
    return total;
}

// ==================== 原函数指针 ====================
static int   (*orig_stat)(const char *, struct stat *)   = NULL;
static int   (*orig_lstat)(const char *, struct stat *)  = NULL;
static int   (*orig_access)(const char *, int)           = NULL;
static int   (*orig_open)(const char *, int, ...)        = NULL;
static FILE *(*orig_fopen)(const char *, const char *)   = NULL;
static char *(*orig_getenv)(const char *)                = NULL;
static const char *(*orig_image_name)(uint32_t)          = NULL;

// ==================== 替换实现 ====================
static int ba_stat(const char *p, struct stat *b) {
    if (ba_pathHidden(p)) { errno = ENOENT; return -1; }
    return orig_stat(p, b);
}
static int ba_lstat(const char *p, struct stat *b) {
    if (ba_pathHidden(p)) { errno = ENOENT; return -1; }
    return orig_lstat(p, b);
}
static int ba_access(const char *p, int m) {
    if (ba_pathHidden(p)) { errno = ENOENT; return -1; }
    return orig_access(p, m);
}
static int ba_open(const char *p, int f, ...) {
    if (ba_pathHidden(p)) { errno = ENOENT; return -1; }
    mode_t mode = 0;
    if (f & O_CREAT) { va_list ap; va_start(ap, f); mode = (mode_t)va_arg(ap, int); va_end(ap); }
    return orig_open(p, f, mode);
}
static FILE *ba_fopen(const char *p, const char *m) {
    if (ba_pathHidden(p)) { errno = ENOENT; return NULL; }
    return orig_fopen(p, m);
}
static char *ba_getenv(const char *k) {
    if (!k) return NULL;
    if (!strcmp(k, "DYLD_INSERT_LIBRARIES") || !strcmp(k, "DYLD_FRAMEWORK_PATH") ||
        !strcmp(k, "_MSSafeMode") || !strcmp(k, "_MSSuppressLogging") ||
        strstr(k, "Substrate") || strstr(k, "substrate") || strstr(k, "BA") == k) {
        return NULL;
    }
    return orig_getenv(k);
}
static const char *ba_image_name(uint32_t i) {
    const char *n = orig_image_name ? orig_image_name(i) : NULL;
    if (n) {
        for (int j = 0; kHiddenSubstr[j]; ++j) {
            if (strstr(n, kHiddenSubstr[j])) return NULL;
        }
    }
    return n;
}

// ==================== ObjC 层 swizzle ====================
static void ba_swizzle(Class cls, SEL orig, SEL repl) {
    Method a = class_getInstanceMethod(cls, orig);
    Method b = class_getInstanceMethod(cls, repl);
    if (a && b) method_exchangeImplementations(a, b);
}

// ==================== 分类实现 ====================
@interface NSFileManager (BAAntiDetect)
- (BOOL)ba_fileExistsAtPath:(NSString *)path;
- (BOOL)ba_isReadableFileAtPath:(NSString *)path;
- (NSDictionary *)ba_attributesOfItemAtPath:(NSString *)path error:(NSError **)error;
- (NSArray *)ba_contentsOfDirectoryAtPath:(NSString *)path error:(NSError **)error;
- (BOOL)ba_createFileAtPath:(NSString *)path contents:(NSData *)c attributes:(NSDictionary *)a;
@end

@implementation NSFileManager (BAAntiDetect)

- (BOOL)ba_fileExistsAtPath:(NSString *)path {
    if (path && ba_pathHidden(path.UTF8String)) return NO;
    return [self ba_fileExistsAtPath:path];
}
- (BOOL)ba_isReadableFileAtPath:(NSString *)path {
    if (path && ba_pathHidden(path.UTF8String)) return NO;
    return [self ba_isReadableFileAtPath:path];
}
- (NSDictionary *)ba_attributesOfItemAtPath:(NSString *)path error:(NSError **)error {
    if (path && ba_pathHidden(path.UTF8String)) {
        if (error) *error = [NSError errorWithDomain:NSCocoaErrorDomain code:260
                                                userInfo:@{NSFilePathErrorKey: path}];
        return nil;
    }
    return [self ba_attributesOfItemAtPath:path error:error];
}
- (NSArray *)ba_contentsOfDirectoryAtPath:(NSString *)path error:(NSError **)error {
    if (path && ba_pathHidden(path.UTF8String)) {
        if (error) *error = [NSError errorWithDomain:NSCocoaErrorDomain code:260
                                                userInfo:@{NSFilePathErrorKey: path}];
        return nil;
    }
    NSArray *r = [self ba_contentsOfDirectoryAtPath:path error:error];
    // 过滤目录列表里的可疑项
    NSMutableArray *out = [NSMutableArray array];
    for (NSString *s in r) {
        if (!ba_pathHidden(s.UTF8String)) [out addObject:s];
    }
    return out;
}
- (BOOL)ba_createFileAtPath:(NSString *)path contents:(NSData *)c attributes:(NSDictionary *)a {
    if (path && ba_pathHidden(path.UTF8String)) return NO;
    return [self ba_createFileAtPath:path contents:c attributes:a];
}

@end

@interface UIApplication (BAAntiDetect)
- (BOOL)ba_canOpenURL:(NSURL *)url;
@end

@implementation UIApplication (BAAntiDetect)

- (BOOL)ba_canOpenURL:(NSURL *)url {
    NSString *s = url.absoluteString.lowercaseString;
    if (s && (ba_pathHidden(url.absoluteString.UTF8String) ||
              [s containsString:@"cydia"] || [s containsString:@"sileo"] ||
              [s containsString:@"zbra"] || [s containsString:@"filza"] ||
              [s containsString:@"undecimus"] || [s containsString:@"substrate"])) {
        return NO;
    }
    return [self ba_canOpenURL:url];
}

@end

// ==================== 对外入口 ====================
@interface BAAntiDetect : NSObject
+ (void)install;
@end

@implementation BAAntiDetect

+ (void)install {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        // ObjC 层
        ba_swizzle([NSFileManager class], @selector(fileExistsAtPath:),
                   @selector(ba_fileExistsAtPath:));
        ba_swizzle([NSFileManager class], @selector(isReadableFileAtPath:),
                   @selector(ba_isReadableFileAtPath:));
        ba_swizzle([NSFileManager class], @selector(attributesOfItemAtPath:error:),
                   @selector(ba_attributesOfItemAtPath:error:));
        ba_swizzle([NSFileManager class], @selector(contentsOfDirectoryAtPath:error:),
                   @selector(ba_contentsOfDirectoryAtPath:error:));
        ba_swizzle([NSFileManager class], @selector(createFileAtPath:contents:attributes:),
                   @selector(ba_createFileAtPath:contents:attributes:));
        ba_swizzle([UIApplication class], @selector(canOpenURL:), @selector(ba_canOpenURL:));

        // C 层: 先 dlsym 兜底, 再 fishhook 绑定
        orig_stat  = (int (*)(const char *, struct stat *))dlsym(RTLD_DEFAULT, "stat");
        orig_lstat = (int (*)(const char *, struct stat *))dlsym(RTLD_DEFAULT, "lstat");
        orig_access= (int (*)(const char *, int))dlsym(RTLD_DEFAULT, "access");
        orig_open  = (int (*)(const char *, int, ...))dlsym(RTLD_DEFAULT, "open");
        orig_fopen = (FILE *(*)(const char *, const char *))dlsym(RTLD_DEFAULT, "fopen");
        orig_getenv= (char *(*)(const char *))dlsym(RTLD_DEFAULT, "getenv");
        orig_image_name = (const char *(*)(uint32_t))dlsym(RTLD_DEFAULT, "_dyld_get_image_name");

        struct ba_rebinding rebs[] = {
            {"stat",                 (void *)ba_stat,       (void **)&orig_stat},
            {"lstat",                (void *)ba_lstat,      (void **)&orig_lstat},
            {"access",               (void *)ba_access,     (void **)&orig_access},
            {"open",                 (void *)ba_open,       (void **)&orig_open},
            {"fopen",                (void *)ba_fopen,      (void **)&orig_fopen},
            {"getenv",               (void *)ba_getenv,     (void **)&orig_getenv},
            {"_dyld_get_image_name", (void *)ba_image_name, (void **)&orig_image_name},
        };
        int bound = ba_rebind_symbols(rebs, sizeof(rebs) / sizeof(rebs[0]));
        NSLog(@"[BA] antiDetect 完成: ObjC 6 处 swizzle, C 层绑定 %d 个槽, 隐藏 %d 条路径",
              bound, (int)(sizeof(kHiddenPaths) / sizeof(kHiddenPaths[0]) - 1));
    });
}

@end
