// BilliardsAim.mm — 注入入口
// 对应原版 __ZL16BilliardsAimInitv @ 0x4000
// 流程: 读配置 -> 反检测 -> 延迟 1.2s -> World.start -> Overlay.attach
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "BAConfig.h"
#import "BAWorld.h"
#import "BAOverlay.h"

@interface BAAntiDetect : NSObject
+ (void)install;
@end

// 等 UIApplication 有 keyWindow 再挂载
static void baWaitForWindow(int tries, void (^done)(void)) {
    if (tries <= 0) { if (done) done(); return; }
    UIWindow *kw = nil;
    for (UIWindow *w in [UIApplication sharedApplication].windows) {
        if (w.isKeyWindow) { kw = w; break; }
    }
    if (kw) { if (done) done(); return; }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        baWaitForWindow(tries - 1, done);
    });
}

__attribute__((constructor))
static void BilliardsAimInit(void) {
    @autoreleasepool {
        NSLog(@"[BA] BilliardsAim %s 载入 (pid=%d)", BA_VERSION, getpid());

        BAConfig *cfg = [BAConfig shared];

        if (cfg.antiDetection) {
            [BAAntiDetect install];
        } else {
            NSLog(@"[BA] antiDetection 关闭");
        }

        // 与原版一致: 1.2 秒后主队列初始化, 等宿主完成启动
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            baWaitForWindow(20, ^{
                BAWorld *w = [BAWorld shared];
                [w start];

                if (cfg.autoProbeOnLaunch) {
                    NSLog(@"[BA] 启动自动测绘...");
                    dispatch_async(dispatch_get_global_queue(0, 0), ^{
                        NSDictionary *r = [w autoProbeWithTable:[cfg table]
                                                     coordinate:cfg.coordMode];
                        NSLog(@"[BA] autoProbe 结果: %@", r);
                    });
                }

                [[BAOverlay shared] attach];
                NSLog(@"[BA] 初始化完成");
            });
        });
    }
}

// 供外部(dlsym/调试)调用
__attribute__((visibility("default")))
void BilliardsAimReload(void) {
    [[BAConfig shared] load];
    [[BAOverlay shared] rebuildHomography];
    NSLog(@"[BA] 配置已重载");
}

__attribute__((visibility("default")))
void BilliardsAimProbe(void) {
    BAConfig *cfg = [BAConfig shared];
    NSDictionary *r = [[BAWorld shared] autoProbeWithTable:[cfg table]
                                                coordinate:cfg.coordMode];
    NSLog(@"[BA] probe: %@", r);
}
