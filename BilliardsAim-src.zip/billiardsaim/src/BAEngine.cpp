// BAEngine.cpp — 台球物理求解引擎
// 对应原 dylib 的 C++ 符号:
//   baDefaultTable baRollDistance baPockets baTrace baStopPoint baSolveShot
//   baBankPocketFromCushion baBestShot baPowerLadder baCushionCoord
//   baMirrorPocket baCurvatureFromSpin baTraceArc baCueDeparture
//   baSolveShotSpin baSolveBank baBestBank baSolveMasse baBestMasse
#include "BACommon.h"
// 不依赖 C++ 标准库: 只用 math.h/string.h, 便于交叉编译到 iOS 且体积更小

// ============ 台面默认值 ============
BATable baDefaultTable(void) {
    BATable t;
    t.length       = 254.0;   // 9 尺台
    t.width        = 127.0;
    t.ballRadius   = 2.85;    // 57.15mm 直径
    t.rollDecel    = 25.0;    // 台呢减速 cm/s^2
    t.cushionRest  = 0.78;    // 库边弹性
    t.maxSpeed     = 900.0;
    t.pocketRadius = 9.0;
    t.pocketCount  = 6;
    return t;
}

int baPocketCount(BATable t) { return (t.pocketCount == 4) ? 4 : 6; }

// 袋口坐标: 6 袋 = 4 角 + 2 中;  4 袋 = 中间四条边
BAVec2 baPocketAt(BATable t, int idx) {
    const double L = t.length, W = t.width;
    if (t.pocketCount == 4) {
        switch (idx & 3) {
            case 0: return BAV(0,      W * 0.5);
            case 1: return BAV(L,      W * 0.5);
            case 2: return BAV(L * 0.5, 0);
            default: return BAV(L * 0.5, W);
        }
    }
    switch (idx % 6) {
        case 0: return BAV(0,     0);
        case 1: return BAV(L * 0.5, 0);
        case 2: return BAV(L,     0);
        case 3: return BAV(0,     W);
        case 4: return BAV(L * 0.5, W);
        default: return BAV(L,    W);
    }
}

// 库边坐标: 0=下(y=0) 1=上(y=W) 2=左(x=0) 3=右(x=L)
double baCushionCoord(BATable t, int i) {
    switch (i & 3) {
        case 0: return 0.0;
        case 1: return t.width;
        case 2: return 0.0;
        default: return t.length;
    }
}

// ============ 滚动距离 ============
// 匀减速: L = v^2 / (2*decel)
double baRollDistance(BATable t, double v) {
    if (t.rollDecel <= 1e-9) return v * 1000.0;
    return (v * v) / (2.0 * t.rollDecel);
}

// 走完距离 d 后剩余速度
static double speedAfter(BATable t, double v0, double d) {
    double v2 = v0 * v0 - 2.0 * t.cushionRest * t.rollDecel * d;
    return (v2 <= 0) ? 0.0 : sqrt(v2);
}

// ============ 库边反弹追踪 ============
// 对应 baTrace: 直线前进, 撞库按 cushionRest 衰减, 记录路径点
int baTrace(BATable t, BAVec2 from, BAVec2 dirIn, double speed,
            BAVec2 *outPts, int maxPts) {
    if (maxPts <= 0) return 0;
    BAVec2 p = from;
    BAVec2 d = baNorm(dirIn);
    if (baLen2(d) < 1e-12) return 0;

    double v = speed;
    int n = 0;
    const double R = t.ballRadius;
    outPts[n++] = p;

    // 最多追踪 8 段库边
    for (int bounce = 0; bounce < 8 && n < maxPts; ++bounce) {
        // 求到四条边的最短正距离
        double tBest = INFINITY;
        int    hitEdge = -1;

        double cand[4];
        // y=0
        if (d.y < -1e-12) {
            cand[0] = (R - p.y) / d.y;
            if (cand[0] > 1e-9 && cand[0] < tBest) { tBest = cand[0]; hitEdge = 0; }
        }
        // y=W
        if (d.y > 1e-12) {
            cand[1] = (t.width - R - p.y) / d.y;
            if (cand[1] > 1e-9 && cand[1] < tBest) { tBest = cand[1]; hitEdge = 1; }
        }
        // x=0
        if (d.x < -1e-12) {
            cand[2] = (R - p.x) / d.x;
            if (cand[2] > 1e-9 && cand[2] < tBest) { tBest = cand[2]; hitEdge = 2; }
        }
        // x=L
        if (d.x > 1e-12) {
            cand[3] = (t.length - R - p.x) / d.x;
            if (cand[3] > 1e-9 && cand[3] < tBest) { tBest = cand[3]; hitEdge = 3; }
        }

        double remain = baRollDistance(t, v);
        if (hitEdge < 0 || tBest > remain) {
            // 中途停下
            p = baAdd(p, baMul(d, remain));
            if (n < maxPts) outPts[n++] = p;
            return n;
        }

        // 到达库边
        p = baAdd(p, baMul(d, tBest));
        if (n < maxPts) outPts[n++] = p;
        v = speedAfter(t, v, tBest);
        v *= t.cushionRest;
        if (v < 1.0) return n;

        // 反射
        switch (hitEdge) {
            case 0: case 1: d.y = -d.y; break;
            default:        d.x = -d.x; break;
        }
    }
    return n;
}

// 对应 baStopPoint: 给定方向和速度, 返回最终停点
BAVec2 baStopPoint(BATable t, BAVec2 from, BAVec2 dir, double speed) {
    BAVec2 pts[12];
    int n = baTrace(t, from, dir, speed, pts, 12);
    return (n > 0) ? pts[n - 1] : from;
}

// ============ 核心: ghost ball 瞄准求解 ============
// 与原版 0x44d8 的浮点序列等价:
//   1. d  = normalize(pocket - target)
//   2. g  = target - 2R * d          // 虚拟球圆心
//   3. c  = normalize(g - cue)
//   4. cos(cut) = dot(c, d)
//   5. cutAngleDeg = acos(clamp) * 180/pi
BAResult baSolveShot(BATable t, BAVec2 cue, BAVec2 target, BAVec2 pocket, double power) {
    BAResult r;
    memset(&r, 0, sizeof(r));
    r.valid = NO;

    BAVec2 d = baNorm(baSub(pocket, target));       // 目标球行进方向
    if (baLen2(d) < 1e-12) return r;

    // 虚拟球圆心: 目标球沿反方向退一个球直径
    BAVec2 g = baSub(target, baMul(d, 2.0 * t.ballRadius));

    BAVec2 cv = baSub(g, cue);                      // 母球 -> 虚拟球
    double dist = baLen(cv);
    if (dist < 1e-9) return r;
    BAVec2 c = baMul(cv, 1.0 / dist);

    // 切角
    double dotc = baDot(c, d);
    dotc = baClamp(dotc, -1.0, 1.0);
    double cut = acos(dotc);
    double cutAbs = (cut > M_PI_2) ? (M_PI - cut) : cut;   // 只取锐角分量

    r.ballIndex   = -1;
    r.pocketIndex = -1;
    r.result.valid    = YES;
    r.result.ghost    = g;
    r.result.hit[0]   = cue;
    r.result.hit[1]   = target;
    r.result.cutAngleDeg = cut * 180.0 / M_PI;

    // ---- 速度链 ----
    double objDist = baLen(baSub(pocket, target));
    // 目标球走完 objDist 所需的初速
    double vObjNeed = sqrt(2.0 * t.rollDecel * (objDist + t.pocketRadius * 0.5));
    // 母球撞上时的速度: 切角越大, 传给目标球的分量越小
    double cosAbs = cos(cutAbs);
    if (cosAbs < 0.02) cosAbs = 0.02;                 // 极限薄球保护
    double vCueAtHit = vObjNeed / cosAbs;
    // 母球从起点到虚拟球距离, 反推出杆初速
    double v0 = sqrt(vCueAtHit * vCueAtHit + 2.0 * t.rollDecel * dist);

    r.result.objectNeedSpeed = vObjNeed;
    r.result.objectHaveSpeed = vCueAtHit * cosAbs;
    r.result.feasible = (v0 <= t.maxSpeed * power) ? YES : NO;

    // 目标球路径 (最多 4 段)
    r.result.objPath[0] = target;
    r.result.objPath[1] = pocket;
    r.result.objPathCount = 2;

    // 评分: 切角小、距离近、力度够 => 分高
    double score = 100.0
                 - fabs(cut) * 180.0 / M_PI * 0.9
                 - objDist * 0.12
                 - (r.result.feasible ? 0.0 : 40.0);
    r.score = score;
    r.valid = (score > 0) ? YES : NO;
    return r;
}

// ============ 翻袋: 镜像法 ============
// 把袋口关于某条库边镜像, 母球直线打向镜像点
BAVec2 baMirrorPocket(BATable t, BAVec2 pocket, int cushion) {
    switch (cushion & 3) {
        case 0: return BAV(pocket.x, -pocket.y);                  // 关于 y=0
        case 1: return BAV(pocket.x, 2.0 * t.width - pocket.y);   // 关于 y=W
        case 2: return BAV(-pocket.x, pocket.y);                  // 关于 x=0
        default: return BAV(2.0 * t.length - pocket.x, pocket.y); // 关于 x=L
    }
}

// 计算翻袋路径并返回是否可行
BOOL baSolveBank(BATable t, BAVec2 cue, BAVec2 target, BAVec2 pocket,
                 int cushion, double power, BAResult *out) {
    BAVec2 mirror = baMirrorPocket(t, pocket, cushion);

    // 母球先撞目标球 => 用 ghost ball, 但虚拟球要朝向镜像点
    BAVec2 d = baNorm(baSub(mirror, target));
    BAVec2 g = baSub(target, baMul(d, 2.0 * t.ballRadius));

    BAVec2 c = baNorm(baSub(g, cue));
    double dotc = baClamp(baDot(c, d), -1.0, 1.0);
    double cut = acos(dotc);

    // 反弹点: 目标球从 target 到镜像点的连线与库边的交点
    BAVec2 bp;
    double tt = 0;
    double coord = baCushionCoord(t, cushion);
    if (cushion < 2) {
        // y 方向库: 0 -> y=0, 1 -> y=W
        if (fabs(d.y) < 1e-9) return NO;
        tt = (coord - target.y) / d.y;
        bp = baAdd(target, baMul(d, tt));
    } else {
        if (fabs(d.x) < 1e-9) return NO;
        tt = (coord - target.x) / d.x;
        bp = baAdd(target, baMul(d, tt));
    }
    if (tt <= 0) return NO;

    // 反弹后方向
    BAVec2 d2 = d;
    if (cushion < 2) d2.y = -d2.y; else d2.x = -d2.x;
    d2 = baNorm(d2);

    // 反弹点到袋口必须共线
    BAVec2 toPocket = baNorm(baSub(pocket, bp));
    if (fabs(baCross(d2, toPocket)) > 0.08) return NO;

    double cutDeg = cut * 180.0 / M_PI;
    if (fabs(cutDeg) > 82.0) return NO;

    double totalObjDist = tt + baLen(baSub(pocket, bp));
    double vObjNeed = sqrt(2.0 * t.rollDecel * totalObjDist / t.cushionRest);
    double cosAbs = fmax(fabs(cos(cut)), 0.02);
    double vCueAtHit = vObjNeed / cosAbs;
    double dist = baLen(baSub(g, cue));
    double v0 = sqrt(vCueAtHit * vCueAtHit + 2.0 * t.rollDecel * dist);

    if (out) {
        memset(out, 0, sizeof(*out));
        out->valid = YES;
        out->result.valid = YES;
        out->result.bounces = 1;
        out->result.cushion[0] = cushion;
        out->result.ghost = g;
        out->result.cutAngleDeg = cutDeg;
        out->result.objectNeedSpeed = vObjNeed;
        out->result.objectHaveSpeed = vCueAtHit * cosAbs;
        out->result.cushionLoss = (1.0 - t.cushionRest) * 100.0;
        out->result.hit[0] = cue;
        out->result.hit[1] = bp;
        out->result.objPath[0] = target;
        out->result.objPath[1] = bp;
        out->result.objPath[2] = pocket;
        out->result.objPathCount = 3;
        out->result.feasible = (v0 <= t.maxSpeed * power) ? YES : NO;
        out->score = 100.0 - fabs(cutDeg) * 0.9 - totalObjDist * 0.12
                     - (out->result.feasible ? 0 : 40.0);
        out->valid = (out->score > 0) ? YES : NO;
    }
    return (v0 <= t.maxSpeed * power) ? YES : NO;
}

// 遍历四条库找最优翻袋
BOOL baBestBank(BATable t, BAVec2 cue, BAVec2 target, BAVec2 pocket,
                int maxBounces, double power, BAResult *out) {
    BOOL found = NO;
    BAResult best; memset(&best, 0, sizeof(best));
    best.score = -1e9;
    int n = (maxBounces <= 0 ? 4 : 4);
    for (int i = 0; i < n; ++i) {
        BAResult r;
        if (baSolveBank(t, cue, target, pocket, i, power, &r) && r.score > best.score) {
            best = r;
            found = YES;
        }
    }
    if (found && out) *out = best;
    return found;
}

// ============ 弧线 / 扎杆 ============
// 曲率 k 与旋转量成正比, 与实际速度平方反比
double baCurvatureFromSpin(double spinV, double speed) {
    if (speed < 1e-6) return 0.0;
    // spinV 归一化到 [-1, 1]
    double s = baClamp(spinV, -1.0, 1.0);
    if (fabs(s) < 1e-6) return 0.0;
    // 经验系数: 满塞在 v=300cm/s 时曲率半径约 300cm
    const double kCoef = 0.0012;
    return s * kCoef * (300.0 * 300.0) / (speed * speed);
}

// 圆弧采样追踪
int baTraceArc(BATable t, BAVec2 from, BAVec2 dirIn,
               double speed, double curvature, BAVec2 *outPts, int maxPts) {
    if (maxPts <= 0) return 0;
    BAVec2 p = from;
    BAVec2 d = baNorm(dirIn);
    double total = baRollDistance(t, speed);
    int n = 0;
    outPts[n++] = p;

    if (fabs(curvature) < 1e-9) {
        // 直线退化
        BAVec2 pts[8];
        int m = baTrace(t, from, dirIn, speed, pts, 8);
        for (int i = 1; i < m && n < maxPts; ++i) outPts[n++] = pts[i];
        return n;
    }

    const double step = 1.0;            // 1cm 积分步长
    const double R = 1.0 / curvature;   // 曲率半径(带符号)
    BAVec2 nrm = BAV(-d.y, d.x);        // 左法向
    BAVec2 center = baAdd(p, baMul(nrm, R));

    double traveled = 0;
    while (traveled < total && n < maxPts) {
        // 绕圆心转一小段
        double dTheta = (step / fabs(R)) * (R > 0 ? 1.0 : -1.0);
        BAVec2 rel = baSub(p, center);
        double ca = cos(dTheta), sa = sin(dTheta);
        BAVec2 rel2 = BAV(rel.x * ca - rel.y * sa, rel.x * sa + rel.y * ca);
        p = baAdd(center, rel2);
        traveled += step;

        // 出界则停
        if (p.x < t.ballRadius || p.x > t.length - t.ballRadius ||
            p.y < t.ballRadius || p.y > t.width - t.ballRadius) {
            outPts[n++] = p;
            break;
        }
        if ((n & 3) == 0 || traveled >= total) outPts[n++] = p;
    }
    return n;
}

// ============ 出杆方向 ============
BAVec2 baCueDeparture(BATable t, BAResult r, BACueAction action,
                      BAVec2 cue, BAVec2 target, BAVec2 pocket) {
    (void)t; (void)target; (void)pocket;
    BAVec2 base = baNorm(baSub(r.result.ghost, cue));
    switch (action) {
        case BACueFollow:
        case BACueDraw: {
            // 高/低杆沿击球轴偏移, 不明显改变瞄准线
            return base;
        }
        case BACueLeft:
        case BACueRight: {
            // 加塞: 方向绕法向偏一点
            double s = (action == BACueLeft) ? 1.0 : -1.0;
            BAVec2 nrm = BAV(-base.y, base.x);
            return baNorm(baAdd(base, baMul(nrm, 0.02 * s)));
        }
        default:
            return base;
    }
}

// ============ 力度阶梯 ============
// 对应 baPowerLadder: 生成 N 档可用力度, 每档给出速度与百分比
int baPowerLadder(BATable t, BAVec2 cue, BAVec2 ghost, BAVec2 pocket,
                  BAPowerRow *rows, int maxRows) {
    if (maxRows <= 0) return 0;
    double dist = baLen(baSub(ghost, cue));
    double objDist = baLen(baSub(pocket, ghost));
    double vNeed = sqrt(2.0 * t.rollDecel * (objDist + dist));

    int n = 0;
    for (int i = 1; i <= maxRows; ++i) {
        double frac = (double)i / (double)maxRows;
        double v = t.maxSpeed * frac;
        rows[n].level = i;
        rows[n].speed = v;
        rows[n].power = (v >= vNeed) ? 1.0 : v / (vNeed > 1e-6 ? vNeed : 1.0);
        ++n;
    }
    return n;
}

// ============ 多球择优 ============
// 对每颗球 x 每个袋口求最优解
int baBestShot(BATable t, BAVec2 cue, BAVec2 *balls, int ballCount,
               int *ballIdx, int pocketCount, double power, BAResult *out) {
    BAResult best; memset(&best, 0, sizeof(best));
    best.score = -1e9;
    BOOL found = NO;

    for (int b = 0; b < ballCount; ++b) {
        if (ballIdx && ballIdx[b] < 0) continue;
        for (int p = 0; p < pocketCount; ++p) {
            BAResult r = baSolveShot(t, cue, balls[b], baPocketAt(t, p), power);
            if (!r.valid) continue;
            if (!r.result.feasible) r.score -= 25.0;
            r.ballIndex = (ballIdx ? ballIdx[b] : b);
            r.pocketIndex = p;
            if (r.score > best.score) { best = r; found = YES; }
        }
    }
    if (found && out) *out = best;
    return found ? 1 : 0;
}

// ============ 扎杆求解 ============
BOOL baSolveMasse(BATable t, BAVec2 cue, BAVec2 target, double spinV,
                  BAVec2 *pockets, int pocketCount, double power, BAResult *out) {
    BAResult best; memset(&best, 0, sizeof(best));
    best.score = -1e9;
    BOOL found = NO;

    for (int p = 0; p < pocketCount; ++p) {
        BAResult r = baSolveShot(t, cue, target, pockets[p], power);
        if (!r.valid) continue;

        double k = baCurvatureFromSpin(spinV, t.maxSpeed * power);

        // 弧线能否把母球带到虚拟球
        BAVec2 dir = baCueDeparture(t, r, BACueCenter, cue, target, pockets[p]);
        BAVec2 pts[16];
        int n = baTraceArc(t, cue, dir, t.maxSpeed * power, k, pts, 16);
        if (n < 2) continue;

        double minDist = 1e9;
        for (int i = 0; i < n; ++i) {
            double dd = baLen(baSub(pts[i], r.result.ghost));
            if (dd < minDist) minDist = dd;
        }
        if (minDist > t.ballRadius * 1.6) continue;

        r.score += 15.0 - minDist * 5.0;
        r.pocketIndex = p;
        if (r.score > best.score) { best = r; found = YES; }
    }
    if (found && out) *out = best;
    return found;
}
