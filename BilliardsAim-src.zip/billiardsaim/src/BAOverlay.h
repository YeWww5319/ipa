// BAOverlay.h — 渲染主控 / 标定 / HUD
#ifndef BA_OVERLAY_H
#define BA_OVERLAY_H

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include "BACommon.h"

@interface BAOverlay : NSObject

+ (instancetype)shared;

- (void)attach;
- (void)detach;
- (void)toggleVisible;

- (void)startCalibration;
- (void)finishCalibrationWithPoints:(NSArray<NSValue *> *)pts;
- (void)rebuildHomography;

// 每帧
- (void)tick;

@end

#endif
