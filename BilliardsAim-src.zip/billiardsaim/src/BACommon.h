// BACommon.h — 公共类型、常量与引擎接口
// 关键: 本头文件被 .m(纯 ObjC/C) 与 .mm/.cpp(C++) 同时包含,
//       因此 C++ 特性全部用 __cplusplus 保护, 引擎接口统一 extern "C",
//       保证 ObjC 侧链接到的是未 mangle 的 C 符号。
#ifndef BA_COMMON_H
#define BA_COMMON_H

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#include <math.h>
#include <string.h>
#include <stdint.h>

#define BA_VERSION "2.0.0"

#ifdef __cplusplus
extern "C" {
#endif

// ---------- 二维向量 ----------
// 保持 C 兼容: 不加构造函数, 便于 ObjC 侧当 POD 使用
// 纯 POD: 无构造函数, 保证 C/C++ 双端 ABI 一致, 可用 memset 清零
typedef struct BAVec2 {
    double x, y;
} BAVec2;

static inline BAVec2 BAV(double x, double y) { BAVec2 v; v.x = x; v.y = y; return v; }
static inline BAVec2 baAdd(BAVec2 a, BAVec2 b) { return BAV(a.x + b.x, a.y + b.y); }
static inline BAVec2 baSub(BAVec2 a, BAVec2 b) { return BAV(a.x - b.x, a.y - b.y); }
static inline BAVec2 baMul(BAVec2 a, double s) { return BAV(a.x * s, a.y * s); }
static inline double baDot(BAVec2 a, BAVec2 b) { return a.x * b.x + a.y * b.y; }
static inline double baCross(BAVec2 a, BAVec2 b) { return a.x * b.y - a.y * b.x; }
static inline double baLen(BAVec2 a) { return sqrt(a.x * a.x + a.y * a.y); }
static inline double baLen2(BAVec2 a) { return a.x * a.x + a.y * a.y; }
static inline double baClamp(double v, double lo, double hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}
static inline BAVec2 baNorm(BAVec2 a) {
    double l = baLen(a);
    if (l < 1e-9) return BAV(0, 0);
    return BAV(a.x / l, a.y / l);
}

// ---------- 球台物理参数 ----------
// 字段偏移与原版一致: +0x00 length, +0x08 width, +0x10 ballRadius,
// +0x18 rollDecel, +0x20 cushionRest, +0x28 maxSpeed, +0x30 pocketRadius
typedef struct BATable {
    double length;
    double width;
    double ballRadius;
    double rollDecel;
    double cushionRest;
    double maxSpeed;
    double pocketRadius;
    int    pocketCount;
} BATable;

// ---------- 杆法 ----------
typedef enum {
    BACueCenter    = 0,
    BACueFollow    = 1,
    BACueDraw      = 2,
    BACueLeft      = 3,
    BACueRight     = 4,
    BACueMasseUp   = 5,
    BACueMasseDown = 6,
} BACueAction;

// ---------- 求解结果 ----------
// 对应原版类型编码 {?="valid"B "ballIndex"i "pocketIndex"i "result"{...} "score"d}
typedef struct BAResult {
    BOOL valid;
    int  ballIndex;
    int  pocketIndex;
    struct {
        BOOL   valid;
        int    bounces;
        int    cushion[2];
        BOOL   feasible;
        BAVec2 hit[2];
        BAVec2 ghost;
        double cutAngleDeg;
        double objectNeedSpeed;
        double objectHaveSpeed;
        double cushionLoss;
        BAVec2 objPath[4];
        int    objPathCount;
    } result;
    double score;
} BAResult;

typedef struct BAPowerRow { int level; double speed; double power; } BAPowerRow;

typedef struct BAHighlight {
    BOOL   hasShot;
    BAVec2 cuePos, targetPos, ghostPos, pocketPos;
    BAVec2 cuePath[8];  int cuePathCount;
    BAVec2 objPath[4];  int objPathCount;
    double cutAngleDeg, needPower;
    int    bounces;
    BOOL   feasible;
} BAHighlight;

// ==================== 引擎接口 (C 链接) ====================
BATable baDefaultTable(void);
BAVec2  baPocketAt(BATable t, int idx);
int     baPocketCount(BATable t);
double  baCushionCoord(BATable t, int i);
double  baRollDistance(BATable t, double v);

int     baTrace(BATable t, BAVec2 from, BAVec2 dir, double speed,
                BAVec2 *outPts, int maxPts);
BAVec2  baStopPoint(BATable t, BAVec2 from, BAVec2 dir, double speed);

BAResult baSolveShot(BATable t, BAVec2 cue, BAVec2 target, BAVec2 pocket, double power);

BAVec2  baMirrorPocket(BATable t, BAVec2 pocket, int cushion);
BOOL    baSolveBank(BATable t, BAVec2 cue, BAVec2 target, BAVec2 pocket,
                    int cushion, double power, BAResult *out);
BOOL    baBestBank(BATable t, BAVec2 cue, BAVec2 target, BAVec2 pocket,
                   int maxBounces, double power, BAResult *out);

double  baCurvatureFromSpin(double spinV, double speed);
int     baTraceArc(BATable t, BAVec2 from, BAVec2 dir, double speed,
                   double curvature, BAVec2 *outPts, int maxPts);
BAVec2  baCueDeparture(BATable t, BAResult r, BACueAction action,
                       BAVec2 cue, BAVec2 target, BAVec2 pocket);

BOOL    baSolveMasse(BATable t, BAVec2 cue, BAVec2 target, double spinV,
                     BAVec2 *pockets, int pocketCount, double power, BAResult *out);

int     baPowerLadder(BATable t, BAVec2 cue, BAVec2 ghost, BAVec2 pocket,
                      BAPowerRow *rows, int maxRows);
int     baBestShot(BATable t, BAVec2 cue, BAVec2 *balls, int ballCount,
                   int *ballIdx, int pocketCount, double power, BAResult *out);

#ifdef __cplusplus
}   // extern "C"
#endif

#endif // BA_COMMON_H
